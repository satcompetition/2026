#ifndef _factorl_h_INCLUDED
#define _factorl_h_INCLUDED

#include <stdbool.h>

struct kissat;

void kissat_factor_learnt (struct kissat *);

#endif
