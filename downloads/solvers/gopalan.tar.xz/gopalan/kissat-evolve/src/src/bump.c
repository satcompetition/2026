#include "bump.h"
#include "analyze.h"
#include "inlineheap.h"
#include "inlinequeue.h"
#include "inlinevector.h"
#include "internal.h"
#include "logging.h"
#include "print.h"
#include "rank.h"
#include "sort.h"

#define RANK(A) ((A).rank)
#define SMALLER(A, B) (RANK (A) < RANK (B))

#define RADIX_SORT_BUMP_LIMIT 32

static void sort_bump (kissat *solver) {
  const size_t size = SIZE_STACK (solver->analyzed);
  if (size < RADIX_SORT_BUMP_LIMIT) {
    LOG ("quick sorting %zu analyzed variables", size);
    SORT_STACK (datarank, solver->ranks, SMALLER);
  } else {
    LOG ("radix sorting %zu analyzed variables", size);
    RADIX_STACK (datarank, unsigned, solver->ranks, RANK);
  }
}

void kissat_rescale_scores (kissat *solver) {
  INC (rescaled);
  heap *scores = &solver->scores;
  const double max_score = kissat_max_score_on_heap (scores);
  kissat_phase (solver, "rescale", GET (rescaled),
                "maximum score %g increment %g", max_score, solver->scinc);
  const double rescale = MAX (max_score, solver->scinc);
  assert (rescale > 0);
  const double factor = 1.0 / rescale;
  kissat_rescale_heap (solver, scores, factor);
  solver->scinc *= factor;
  kissat_phase (solver, "rescale", GET (rescaled), "rescaled by factor %g",
                factor);
}
void kissat_bump_score_increment (kissat *solver) {
  // Step 1: Calculate the base EVSIDS multiplier factor M = 1.0 / (1.0 - decay)
  const double decay_per_mille = GET_OPTION (decay);
  const double decay = decay_per_mille * 1e-3;
  const double M = 1.0 / (1.0 - decay);

  // Step 2: Retrieve the short-term (fast) and long-term (slow) EMAs of the LBD
  // In Kissat, these are stored as fast_glue and slow_glue in the averages struct.
  const double glue_fast = solver->averages[solver->stable].fast_glue.value;
  const double glue_slow = solver->averages[solver->stable].slow_glue.value;

  // Step 3: Calculate the Learning Efficiency Ratio ρ = glue_fast / glue_slow
  const double rho = (glue_slow > 0.0) ? (glue_fast / glue_slow) : 1.0;

  // Step 4: Compute a Momentum Adjuster A = 1.0 + clamp(0.1 * (ρ - 1.0), -0.02, 0.02)
  double diff = 0.1 * (rho - 1.0);
  if (diff < -0.02)
    diff = -0.02;
  else if (diff > 0.02)
    diff = 0.02;
  const double A = 1.0 + diff;

  // Step 5: Update the global score increment using an asymmetric scaling formula
  const double adj = (A > 1.0) ? (A * A) : A;
  solver->scinc *= (M * adj);

  LOG ("new score increment %g (rho %g, A %g, adj %g)", solver->scinc, rho, A, adj);

  // Step 6: Momentum-Aware Rescale
  if (solver->scinc > MAX_SCORE) {
    if (rho > 1.0) {
      // Apply a 'Deep Compression' by multiplying all variable scores by 1e-160
      // We achieve this by setting scinc to 1e160 so kissat_rescale_scores uses factor 1e-160
      solver->scinc = 1e160;
      kissat_rescale_scores (solver);
      // Reset solver->scinc to 1.0 as per instructions
      solver->scinc = 1.0;
    } else {
      // Perform the standard kissat_rescale_scores (factor ~1e-150)
      kissat_rescale_scores (solver);
    }
  }
}

static inline void bump_analyzed_variable_score (kissat *solver,
                                                 unsigned idx) {
  heap *scores = &solver->scores;
  const double old_score = kissat_get_heap_score (scores, idx);
  const double inc = solver->scinc;
  const double new_score = old_score + inc;
  LOG ("new score[%u] = %g = %g + %g", idx, new_score, old_score, inc);
  kissat_update_heap (solver, scores, idx, new_score);
  if (new_score > MAX_SCORE)
    kissat_rescale_scores (solver);
}

void kissat_bump_variable (kissat *solver, unsigned idx) {
  bump_analyzed_variable_score (solver, idx);
}

static void bump_analyzed_variable_scores (kissat *solver) {
  flags *flags = solver->flags;

  for (all_stack (unsigned, idx, solver->analyzed))
    if (flags[idx].active)
      bump_analyzed_variable_score (solver, idx);

  kissat_bump_score_increment (solver);
}

static void move_analyzed_variables_to_front_of_queue (kissat *solver) {
  assert (EMPTY_STACK (solver->ranks));
  const links *const links = solver->links;
  for (all_stack (unsigned, idx, solver->analyzed)) {
    // clang-format off
    const datarank rank = { .data = idx, .rank = links[idx].stamp };
    // clang-format on
    PUSH_STACK (solver->ranks, rank);
  }

  sort_bump (solver);

  flags *flags = solver->flags;
  unsigned idx;

  for (all_stack (datarank, rank, solver->ranks))
    if (flags[idx = rank.data].active)
      kissat_move_to_front (solver, idx);

  CLEAR_STACK (solver->ranks);
}

void kissat_bump_analyzed (kissat *solver) {
  START (bump);
  const size_t bumped = SIZE_STACK (solver->analyzed);
  if (!solver->stable)
    move_analyzed_variables_to_front_of_queue (solver);
  else
    bump_analyzed_variable_scores (solver);
  ADD (literals_bumped, bumped);
  STOP (bump);
}

void kissat_update_scores (kissat *solver) {
  assert (solver->stable);
  heap *scores = kissat_get_scores(solver);
  for (all_variables (idx))
    if (ACTIVE (idx) && !kissat_heap_contains (scores, idx))
      kissat_push_heap (solver, scores, idx);
}

// CHB

void kissat_bump_chb(kissat * solver, unsigned v, double multiplier) {
  int64_t age = solver->statistics.conflicts - solver->conflicted_chb[v] + 1;
  double reward_chb = multiplier / age;
  double old_score = kissat_get_heap_score (&solver->scores_chb, v);
  double new_score = solver->step_chb * reward_chb + (1 - solver->step_chb) * old_score;
  LOG ("new score[%u] = %g vs %g",
     v, new_score, old_score);
  kissat_update_heap (solver, &solver->scores_chb, v, new_score);
}

void kissat_decay_chb(kissat * solver){
  if (solver->step_chb > solver->step_min_chb) solver->step_chb -= solver->step_dec_chb;
}

void
kissat_update_conflicted_chb (kissat * solver)
{
flags *flags = solver->flags;

for (all_stack (unsigned, idx, solver->analyzed))
  if (flags[idx].active)
      solver->conflicted_chb[idx]=solver->statistics.conflicts;
}
