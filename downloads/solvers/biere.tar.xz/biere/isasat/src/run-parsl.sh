#!/bin/bash
# run-parsl.sh — call binary directly (solver: isasat)
# Usage: ./run-parsl.sh <cnf> <proof_output_file>
cd "$(dirname "$0")"
CNF="$1"
PROOF="$2"
./Weidenbach_Book/IsaSAT/code/src/isasat "$CNF" "$PROOF"
