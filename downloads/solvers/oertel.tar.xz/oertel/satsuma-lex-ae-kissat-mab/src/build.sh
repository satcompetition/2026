#!/bin/bash

set -e

# Build satsuma
echo "Building satsuma..."
cd satsuma-src
make clean
make satsuma
cp satsuma ../satsuma
cd ..

# Build kissat
echo "Building kissat..."
cd kissat-hack
./configure
make kissat
cp build/kissat ../kissat
cd ..
