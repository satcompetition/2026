#!/bin/bash
# run-parsl.sh — call binary directly (solver: satsuma-lex-ae-kissat-mab)
# Usage: ./run-parsl.sh <cnf> <proof_output_file>
cd "$(dirname "$0")"
CNF="$1"
PROOF="$2"
N=$(grep -m1 "^p cnf" "$CNF" | cut -d" " -f3); D=$(dirname "$PROOF"); if [ ${N:-0} -lt 5000000 ]; then ./satsuma --silent --proof-dense-crossover 60 --component-limit 500000 --order-model-limit 750000 --dense-model-limit 20000000 --add-reduced-as-unit --preprocess-cnf-unit -f "$CNF" --proof-file "$PROOF" --out-file $D/temporary.cnf; ./kissat -q --no-binary --witnessmaxvar=$N $D/temporary.cnf "$PROOF"; else echo "pseudo-Boolean proof version 3.0" > "$PROOF"; ./kissat -q --no-binary --witnessmaxvar=$N "$CNF" "$PROOF"; fi; R=$?; [ $R -eq 20 ] && { echo "output NONE;" >> "$PROOF"; echo "conclusion UNSAT;" >> "$PROOF"; echo "end pseudo-Boolean proof;" >> "$PROOF"; }; rm -f $D/temporary.cnf; exit $R
