#!/bin/bash
# run-parsl.sh — call binary directly (solver: kissat-mab-hypre-evolve)
# Usage: ./run-parsl.sh <cnf> <proof_output_file>
cd "$(dirname "$0")"
input_file="$1"
proof_file="$2"

while IFS= read -r line; do
    if [[ $line == p\ * ]]; then
        read -r _ _ N _ <<< "$line"
        break
    fi
done < "$input_file"

temporary_cnf="$(basename "$input_file").temporary.cnf"

SE=0
if [ "${N:-0}" -lt 5000000 ]; then
    ./Satsuma/satsuma --proof-dense-crossover 60 --component-limit 500000 --order-model-limit 750000 --dense-model-limit 20000000 --add-reduced-as-unit --preprocess-cnf-unit -f "$input_file" --proof-file "$proof_file" --out-file "$temporary_cnf" --silent
    SE=$?
    if [ $SE -eq 0 ]; then
        ./build/kissat "$temporary_cnf" "$proof_file" --no-binary -q --witnessmaxvar="$N"
    fi
else
    echo "pseudo-Boolean proof version 3.0" > "$proof_file"
    ./build/kissat "$input_file" "$proof_file" --no-binary -q --witnessmaxvar="$N"
fi

R=$?
if [ $SE -eq 1 ] || [ $R -eq 20 ]; then
    echo "output NONE;" >> "$proof_file"
    echo "conclusion UNSAT;" >> "$proof_file"
    echo "end pseudo-Boolean proof;" >> "$proof_file"
fi

if [ -f "$temporary_cnf" ]; then
    rm "$temporary_cnf"
fi
exit $R
