cd ./Satsuma
make satsuma
cd ..
./configure
make