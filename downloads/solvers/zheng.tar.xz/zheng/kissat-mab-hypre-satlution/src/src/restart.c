#include "restart.h"
#include "backtrack.h"
#include "bump.h"
#include "decide.h"
#include "internal.h"
#include "kimits.h"
#include "logging.h"
#include "print.h"
#include "reluctant.h"
#include "report.h"

#include <inttypes.h>
#include <math.h>

bool kissat_restarting (kissat *solver) {
  assert (solver->unassigned);
  if (!GET_OPTION (restart))
    return false;
  if (!solver->level)
    return false;
  if (CONFLICTS < solver->limits.restart.conflicts)
    return false;
  if (solver->stable)
    return kissat_reluctant_triggered (&solver->reluctant);
  const double fast = AVERAGE (fast_glue);
  const double slow = AVERAGE (slow_glue);
  const double margin = (100.0 + GET_OPTION (restartmargin)) / 100.0;
  const double limit = margin * slow;
  kissat_extremely_verbose (solver,
                            "restart glue limit %g = "
                            "%.02f * %g (slow glue) %c %g (fast glue)",
                            limit, margin, slow,
                            (limit > fast    ? '>'
                             : limit == fast ? '='
                                             : '<'),
                            fast);
  return (limit <= fast);
}

void kissat_update_focused_restart_limit (kissat *solver) {
  assert (!solver->stable);
  limits *limits = &solver->limits;
  uint64_t restarts = solver->statistics.restarts;
  uint64_t delta = GET_OPTION (restartint);
  if (restarts)
    delta += kissat_logn (restarts) - 1;
  limits->restart.conflicts = CONFLICTS + delta;
  kissat_extremely_verbose (solver,
                            "focused restart limit at %" PRIu64
                            " after %" PRIu64 " conflicts ",
                            limits->restart.conflicts, delta);
}

static unsigned reuse_stable_trail (kissat *solver) {
  const heap *const scores = kissat_get_scores (solver);
  const unsigned next_idx = kissat_next_decision_variable (solver);
  const double limit = kissat_get_heap_score (scores, next_idx);
  unsigned level = solver->level, res = 0;
  while (res < level) {
    frame *f = &FRAME (res + 1);
    const unsigned idx = IDX (f->decision);
    const double score = kissat_get_heap_score (scores, idx);
    if (score <= limit)
      break;
    res++;
  }
  return res;
}

static unsigned reuse_focused_trail (kissat *solver) {
  const links *const links = solver->links;
  const unsigned next_idx = kissat_next_decision_variable (solver);
  const unsigned limit = links[next_idx].stamp;
  LOG ("next decision variable stamp %u", limit);
  unsigned level = solver->level, res = 0;
  while (res < level) {
    frame *f = &FRAME (res + 1);
    const unsigned idx = IDX (f->decision);
    const unsigned score = links[idx].stamp;
    if (score <= limit)
      break;
    res++;
  }
  return res;
}

static unsigned reuse_trail (kissat *solver) {
  assert (solver->level);
  assert (!EMPTY_STACK (solver->trail));

  if (!GET_OPTION (restartreusetrail))
    return 0;

  unsigned res;

  if (solver->stable)
    res = reuse_stable_trail (solver);
  else
    res = reuse_focused_trail (solver);

  LOG ("matching trail level %u", res);

  if (res) {
    INC (restarts_reused_trails);
    ADD (restarts_reused_levels, res);
    LOG ("restart reuses trail at decision level %u", res);
  } else
    LOG ("restarts does not reuse the trail");

  return res;
}

void restart_mab (kissat *solver) {
  unsigned stable_restarts = 0;
  if (0 == solver->strategy)
    solver->mab_reward[solver->heuristic] +=
        log2 (solver->mab_decisions) / log2 (solver->mab_conflicts);
  else
    solver->mab_reward[2 + solver->heuristic] +=
        log2 (solver->mab_conflicts) / log2 (solver->mab_decisions);

  for (all_variables (idx)) {
    solver->mab_chosen[idx] = 0;
  }
  solver->mab_chosen_tot = 0;
  solver->mab_decisions = 0;
  solver->mab_conflicts = 0;

  for (unsigned i = 0; i < solver->mab_heuristics; i++) {
    stable_restarts += solver->mab_select[solver->strategy * 2 + i];
  }

  static double recent_gains[20] = {0};
  static int gain_index[2] = {0};
  static double momentum = 1.0;
  bool switch_strategy = true;
  static int stay_count = 0;

  double current_gain =
      solver->mab_reward[solver->strategy * 2 + solver->heuristic] /
      solver->mab_select[solver->strategy * 2 + solver->heuristic];
  recent_gains[solver->strategy * 10 + gain_index[solver->strategy]] =
      current_gain;
  gain_index[solver->strategy] = (gain_index[solver->strategy] + 1) % 10;

  double avg_gain = 0;
  for (int i = 0; i < 10; i++) {
    avg_gain += recent_gains[solver->strategy * 10 + i];
  }
  avg_gain /= 10;

  if (current_gain > avg_gain) {
    momentum *= 1.1;
  } else {
    momentum *= 0.9;
  }

  double adaptive_c = solver->mabc / (momentum * (stable_restarts + 1));

  if (stable_restarts < solver->mab_heuristics) {
    solver->next_heuristic[solver->strategy] =
        solver->heuristic == 0 ? 1 : 0;
  } else {
    double ucb[2];
    solver->next_heuristic[solver->strategy] = 0;
    if (solver->heuristic == 0)
    {
      ucb[0] = solver->mab_reward[solver->strategy * 2] /
                   solver->mab_select[solver->strategy * 2] +
               sqrt(adaptive_c * log(stable_restarts + 1) /
                    solver->mab_select[solver->strategy * 2]);
      ucb[1] = solver->mab_reward[solver->strategy * 2 + 1] /
                   solver->mab_select[solver->strategy * 2 + 1] +
               sqrt(adaptive_c * log(stable_restarts + 1) /
                    solver->mab_select[solver->strategy * 2 + 1]);
      if (ucb[1] > ucb[0])
      {
        solver->next_heuristic[solver->strategy] = 1;
      }
    }
  }
  if (stay_count < 10) {
    switch_strategy = false;
    stay_count++;
  }
  if (switch_strategy) {
    solver->strategy = 1 - solver->strategy;
    stay_count = 0;
  }
  solver->heuristic = solver->next_heuristic[solver->strategy];

  solver->mab_select[solver->strategy * 2 + solver->heuristic]++;
}

void kissat_restart (kissat *solver) {
  START (restart);
  INC (restarts);
  ADD (restarts_levels, solver->level);
  if (solver->stable)
    INC (stable_restarts);
  else
    INC (focused_restarts);

  unsigned old_heuristic = solver->heuristic;
  if (solver->stable && solver->mab)
    restart_mab (solver);
  unsigned new_heuristic = solver->heuristic;

  unsigned level =
      old_heuristic == new_heuristic ? reuse_trail (solver) : 0;

  kissat_extremely_verbose (solver,
                            "restarting after %" PRIu64 " conflicts"
                            " (limit %" PRIu64 ")",
                            CONFLICTS, solver->limits.restart.conflicts);
  LOG ("restarting to level %u", level);
  if (solver->stable && solver->mab)
    solver->heuristic = old_heuristic;
  kissat_backtrack_in_consistent_state (solver, level);
  if (solver->stable && solver->mab)
    solver->heuristic = new_heuristic;
  if (!solver->stable)
    kissat_update_focused_restart_limit (solver);

  if (solver->stable && solver->mab && old_heuristic != new_heuristic)
    kissat_update_scores (solver);

  REPORT (1, 'R');
  STOP (restart);
}
