#!/bin/bash

if [ $# -ne 2 ]; then
    echo "Usage: $0 <benchmark-instance> <output-dir>"
    exit 1
fi

input_file="$1"
output_dir="$2"
proof_file="$output_dir/proof.out"

while IFS= read -r line; do
    if [[ $line == p\ * ]]; then
        read -r _ _ N _ <<< "$line"
        break
    fi
done < "$1"

input_basename=$(basename "$input_file")
temporary_cnf="${input_basename}.temporary.cnf"

SATSUMA_EXIT=0
if [ "$N" -lt 5000000 ]; then
    ./Satsuma/satsuma --proof-dense-crossover 60 --component-limit 500000 --order-model-limit 750000 --dense-model-limit 20000000 --add-reduced-as-unit --preprocess-cnf-unit -f "$input_file" --proof-file "$proof_file" --out-file "$temporary_cnf" --silent
    SATSUMA_EXIT=$?
    if [ $SATSUMA_EXIT -eq 0 ]; then
        ./build/kissat "$temporary_cnf" "$proof_file" --no-binary -q --witnessmaxvar="$N"
    fi
else
    echo "pseudo-Boolean proof version 3.0" > "$proof_file"
    ./build/kissat "$input_file" "$proof_file" --no-binary -q --witnessmaxvar="$N"
fi

KISSAT_EXIT=$?
if [ $SATSUMA_EXIT -eq 1 ]; then
    echo "output NONE;" >> "$proof_file"
    echo "conclusion UNSAT;" >> "$proof_file"
    echo "end pseudo-Boolean proof;" >> "$proof_file"
elif [ $KISSAT_EXIT -eq 20 ]; then
    echo "output NONE;" >> "$proof_file"
    echo "conclusion UNSAT;" >> "$proof_file"
    echo "end pseudo-Boolean proof;" >> "$proof_file"
fi

if [ -f "$temporary_cnf" ]; then 
    rm "$temporary_cnf"
fi