(cd cadical; ./configure && make)
