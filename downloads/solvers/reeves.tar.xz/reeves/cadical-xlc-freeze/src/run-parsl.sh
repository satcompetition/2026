#!/bin/bash
# run-parsl.sh — call binary directly (solver: cadical-xlc-freeze)
# Usage: ./run-parsl.sh <cnf> <proof_output_file>
cd "$(dirname "$0")"
CNF="$1"
PROOF="$2"
./cadical/build/cadical "$CNF" "$PROOF" --ulc --ulctype=3 --ulcfreeze=1
