file(REMOVE_RECURSE
  "CMakeFiles/matcher_obj_52_karatsuba_multiplication.dir/solvers/karatsuba-multiplication/matcher/match.cpp.o"
  "CMakeFiles/matcher_obj_52_karatsuba_multiplication.dir/solvers/karatsuba-multiplication/matcher/match.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/matcher_obj_52_karatsuba_multiplication.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
