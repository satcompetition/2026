file(REMOVE_RECURSE
  "CMakeFiles/matcher_obj_115_tensors.dir/solvers/tensors/matcher/match.cpp.o"
  "CMakeFiles/matcher_obj_115_tensors.dir/solvers/tensors/matcher/match.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/matcher_obj_115_tensors.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
