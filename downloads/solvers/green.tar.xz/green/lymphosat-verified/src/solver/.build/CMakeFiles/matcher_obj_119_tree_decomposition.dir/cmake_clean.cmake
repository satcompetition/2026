file(REMOVE_RECURSE
  "CMakeFiles/matcher_obj_119_tree_decomposition.dir/solvers/tree-decomposition/matcher/match.cpp.o"
  "CMakeFiles/matcher_obj_119_tree_decomposition.dir/solvers/tree-decomposition/matcher/match.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/matcher_obj_119_tree_decomposition.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
