# Empty dependencies file for matcher_obj_23_cryptography_simon.
# This may be replaced when dependencies are built.
