# Empty dependencies file for matcher_obj_60_minimum_disagreement_parity.
# This may be replaced when dependencies are built.
