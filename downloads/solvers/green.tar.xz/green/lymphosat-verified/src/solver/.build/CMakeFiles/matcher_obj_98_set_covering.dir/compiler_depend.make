# Empty compiler generated dependencies file for matcher_obj_98_set_covering.
# This may be replaced when dependencies are built.
