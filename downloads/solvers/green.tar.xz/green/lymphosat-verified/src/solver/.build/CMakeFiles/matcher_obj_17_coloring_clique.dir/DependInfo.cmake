
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/iser/Documents/satcomp/satcomp2026/solvers/green/lymphosat-verified/src/solver/solvers/coloring-clique/matcher/match.cpp" "CMakeFiles/matcher_obj_17_coloring_clique.dir/solvers/coloring-clique/matcher/match.cpp.o" "gcc" "CMakeFiles/matcher_obj_17_coloring_clique.dir/solvers/coloring-clique/matcher/match.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
