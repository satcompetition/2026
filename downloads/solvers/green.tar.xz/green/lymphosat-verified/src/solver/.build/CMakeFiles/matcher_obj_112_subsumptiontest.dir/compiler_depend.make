# Empty compiler generated dependencies file for matcher_obj_112_subsumptiontest.
# This may be replaced when dependencies are built.
