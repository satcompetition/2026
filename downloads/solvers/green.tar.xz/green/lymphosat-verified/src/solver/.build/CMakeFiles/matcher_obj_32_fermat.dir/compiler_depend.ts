# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for matcher_obj_32_fermat.
