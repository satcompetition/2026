# Empty compiler generated dependencies file for matcher_obj_25_diagnosis.
# This may be replaced when dependencies are built.
