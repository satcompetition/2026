file(REMOVE_RECURSE
  "CMakeFiles/matcher_obj_30_erdos_discrepancy.dir/solvers/erdos-discrepancy/matcher/match.cpp.o"
  "CMakeFiles/matcher_obj_30_erdos_discrepancy.dir/solvers/erdos-discrepancy/matcher/match.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/matcher_obj_30_erdos_discrepancy.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
