# Empty dependencies file for matcher_obj_52_karatsuba_multiplication.
# This may be replaced when dependencies are built.
