# Empty dependencies file for matcher_obj_117_testpattern_generation.
# This may be replaced when dependencies are built.
