# Empty compiler generated dependencies file for matcher_obj_30_erdos_discrepancy.
# This may be replaced when dependencies are built.
