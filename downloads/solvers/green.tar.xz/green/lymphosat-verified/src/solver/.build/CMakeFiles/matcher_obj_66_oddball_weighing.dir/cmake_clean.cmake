file(REMOVE_RECURSE
  "CMakeFiles/matcher_obj_66_oddball_weighing.dir/solvers/oddball-weighing/matcher/match.cpp.o"
  "CMakeFiles/matcher_obj_66_oddball_weighing.dir/solvers/oddball-weighing/matcher/match.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/matcher_obj_66_oddball_weighing.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
