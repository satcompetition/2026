file(REMOVE_RECURSE
  "CMakeFiles/matcher_obj_17_coloring_clique.dir/solvers/coloring-clique/matcher/match.cpp.o"
  "CMakeFiles/matcher_obj_17_coloring_clique.dir/solvers/coloring-clique/matcher/match.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/matcher_obj_17_coloring_clique.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
