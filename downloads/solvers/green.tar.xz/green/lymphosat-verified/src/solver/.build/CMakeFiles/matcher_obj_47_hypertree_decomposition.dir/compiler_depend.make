# Empty compiler generated dependencies file for matcher_obj_47_hypertree_decomposition.
# This may be replaced when dependencies are built.
