# Empty compiler generated dependencies file for matcher_obj_32_fermat.
# This may be replaced when dependencies are built.
