file(REMOVE_RECURSE
  "CMakeFiles/matcher_obj_21_cryptography_ascon.dir/solvers/cryptography-ascon/matcher/match.cpp.o"
  "CMakeFiles/matcher_obj_21_cryptography_ascon.dir/solvers/cryptography-ascon/matcher/match.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/matcher_obj_21_cryptography_ascon.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
