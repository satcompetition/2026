# Empty compiler generated dependencies file for matcher_obj_59_minimal_superpermutation.
# This may be replaced when dependencies are built.
