file(REMOVE_RECURSE
  "CMakeFiles/matcher_obj_59_minimal_superpermutation.dir/solvers/minimal-superpermutation/matcher/match.cpp.o"
  "CMakeFiles/matcher_obj_59_minimal_superpermutation.dir/solvers/minimal-superpermutation/matcher/match.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/matcher_obj_59_minimal_superpermutation.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
