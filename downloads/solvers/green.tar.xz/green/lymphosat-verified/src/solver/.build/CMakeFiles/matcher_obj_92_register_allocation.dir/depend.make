# Empty dependencies file for matcher_obj_92_register_allocation.
# This may be replaced when dependencies are built.
