file(REMOVE_RECURSE
  "CMakeFiles/matcher_obj_1_algebra.dir/solvers/algebra/matcher/match.cpp.o"
  "CMakeFiles/matcher_obj_1_algebra.dir/solvers/algebra/matcher/match.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/matcher_obj_1_algebra.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
