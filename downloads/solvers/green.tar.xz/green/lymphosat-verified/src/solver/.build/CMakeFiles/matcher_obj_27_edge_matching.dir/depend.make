# Empty dependencies file for matcher_obj_27_edge_matching.
# This may be replaced when dependencies are built.
