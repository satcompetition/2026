# Empty compiler generated dependencies file for matcher_obj_119_tree_decomposition.
# This may be replaced when dependencies are built.
