file(REMOVE_RECURSE
  "CMakeFiles/matcher_obj_36_genurq.dir/solvers/genurq/matcher/match.cpp.o"
  "CMakeFiles/matcher_obj_36_genurq.dir/solvers/genurq/matcher/match.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/matcher_obj_36_genurq.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
