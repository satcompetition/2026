file(REMOVE_RECURSE
  "CMakeFiles/matcher_obj_14_clique_formulas.dir/solvers/clique-formulas/matcher/match.cpp.o"
  "CMakeFiles/matcher_obj_14_clique_formulas.dir/solvers/clique-formulas/matcher/match.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/matcher_obj_14_clique_formulas.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
