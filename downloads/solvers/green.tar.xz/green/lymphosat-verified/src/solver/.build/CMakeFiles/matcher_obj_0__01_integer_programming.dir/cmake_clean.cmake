file(REMOVE_RECURSE
  "CMakeFiles/matcher_obj_0__01_integer_programming.dir/solvers/01-integer-programming/matcher/match.cpp.o"
  "CMakeFiles/matcher_obj_0__01_integer_programming.dir/solvers/01-integer-programming/matcher/match.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/matcher_obj_0__01_integer_programming.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
