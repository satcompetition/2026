# Empty compiler generated dependencies file for matcher_obj_84_ramseycube.
# This may be replaced when dependencies are built.
