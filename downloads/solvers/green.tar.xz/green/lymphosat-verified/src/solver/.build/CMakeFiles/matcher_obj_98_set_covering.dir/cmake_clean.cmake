file(REMOVE_RECURSE
  "CMakeFiles/matcher_obj_98_set_covering.dir/solvers/set-covering/matcher/match.cpp.o"
  "CMakeFiles/matcher_obj_98_set_covering.dir/solvers/set-covering/matcher/match.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/matcher_obj_98_set_covering.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
