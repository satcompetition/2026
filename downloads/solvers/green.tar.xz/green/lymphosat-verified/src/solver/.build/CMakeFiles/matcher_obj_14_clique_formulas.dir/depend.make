# Empty dependencies file for matcher_obj_14_clique_formulas.
# This may be replaced when dependencies are built.
