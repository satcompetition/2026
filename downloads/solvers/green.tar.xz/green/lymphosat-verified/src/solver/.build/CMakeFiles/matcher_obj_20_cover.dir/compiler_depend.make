# Empty compiler generated dependencies file for matcher_obj_20_cover.
# This may be replaced when dependencies are built.
