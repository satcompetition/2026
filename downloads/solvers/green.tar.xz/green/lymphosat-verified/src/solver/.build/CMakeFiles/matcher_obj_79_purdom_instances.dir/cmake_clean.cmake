file(REMOVE_RECURSE
  "CMakeFiles/matcher_obj_79_purdom_instances.dir/solvers/purdom-instances/matcher/match.cpp.o"
  "CMakeFiles/matcher_obj_79_purdom_instances.dir/solvers/purdom-instances/matcher/match.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/matcher_obj_79_purdom_instances.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
