# Empty compiler generated dependencies file for matcher_obj_37_gf3_sat.
# This may be replaced when dependencies are built.
