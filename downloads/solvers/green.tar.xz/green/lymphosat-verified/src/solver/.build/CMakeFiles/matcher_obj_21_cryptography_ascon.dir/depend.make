# Empty dependencies file for matcher_obj_21_cryptography_ascon.
# This may be replaced when dependencies are built.
