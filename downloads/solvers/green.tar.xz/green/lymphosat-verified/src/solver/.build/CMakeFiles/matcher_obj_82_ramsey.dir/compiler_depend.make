# Empty compiler generated dependencies file for matcher_obj_82_ramsey.
# This may be replaced when dependencies are built.
