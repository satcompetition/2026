# Empty compiler generated dependencies file for matcher_obj_17_coloring_clique.
# This may be replaced when dependencies are built.
