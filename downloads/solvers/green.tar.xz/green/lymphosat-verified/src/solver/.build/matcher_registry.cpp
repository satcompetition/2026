#include "formula_profile.h"
#include <vector>

extern "C" bool lymphosat_match_matcher_0__01_integer_programming(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_1_algebra(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_2_algorithm_equivalence_checking(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_3_alloy_vpn_models(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_4_antibandwidth(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_5_auto_correlation(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_6_automata_synchronization(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_7_battleship(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_8_binary_pigeon_hole(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_9_binary_tree_parity(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_10_brent_equations(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_11_circuit_equialence_checking(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_12_circuit_minimization(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_13_clique_coloring(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_14_clique_formulas(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_15_clique_width(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_16_clustered_random(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_17_coloring_clique(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_18_coloring_mycielski_graph(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_19_core_based_generator(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_20_cover(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_21_cryptography_ascon(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_22_cryptography_cbmc(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_23_cryptography_simon(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_24_design_debugging(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_25_diagnosis(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_26_discrete_logarithm(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_27_edge_matching(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_28_edit_distance(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_29_equivalence_chain_principle(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_30_erdos_discrepancy(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_31_fdmus(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_32_fermat(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_33_fixed_shape_random(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_34_floodit_puzzle(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_35_fpga_routing(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_36_genurq(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_37_gf3_sat(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_38_glassy_gen(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_39_graceful_production(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_40_grandtour_puzzle(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_41_greentao(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_42_hamiltonian_cycle(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_43_hanoi(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_44_heule_nol(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_45_hgen(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_46_hidoku(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_47_hypertree_decomposition(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_48_independent_set(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_49_independent_set_reconfiguration(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_50_influence_maximization(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_51_interval_matching(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_52_karatsuba_multiplication(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_53_knights_problem(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_54_ktf(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_55_long_learned_clauses(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_56_maximum_constraint_partition(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_57_md5_equivalence_checking(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_58_mechanical_master_key(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_59_minimal_superpermutation(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_60_minimum_disagreement_parity(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_61_modcircuits(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_62_mosoi_289(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_63_multiplier_circuits(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_64_multiplier_verification(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_65_mutilated_chessboard(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_66_oddball_weighing(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_67_or_randxor(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_68_ordering_principle(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_69_ordering_principle_xor(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_70_p_center(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_71_pebbling(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_72_petrinet_concurrency(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_73_philips(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_74_phnf(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_75_pigeon_hole(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_76_planning(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_77_product_configuration(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_78_profitable_robust_production(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_79_purdom_instances(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_80_pythagorean_triples(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_81_railway_safety(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_82_ramsey(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_83_ramsey_numbers(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_84_ramseycube(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_85_random(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_86_random_circuits(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_87_random_clustered(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_88_random_csp(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_89_random_mus(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_90_random_planted_solution(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_91_rbsat(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_92_register_allocation(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_93_relational_dependencies(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_94_relativized_pigeon_hole(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_95_rooks(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_96_sat_x(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_97_satcoin(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_98_set_covering(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_99_sgen(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_100_sgen_balanced(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_101_sliding_puzzle(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_102_social_golfer(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_103_software_bmc(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_104_software_verification(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_105_sorting_networks(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_106_ssp_0(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_107_st_connectivity_principle(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_108_station_repacking(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_109_stedman_triples(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_110_stone(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_111_subgraph_isomorphism(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_112_subsumptiontest(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_113_sum_of_3_cubes(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_114_summle(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_115_tensors(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_116_test_configuration(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_117_testpattern_generation(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_118_theorem_proving(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_119_tree_decomposition(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_120_trigonometric_functions(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_121_tseitin_formulas(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_122_uniform_random(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_123_waerden(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_124_xor_chain(const lymphosat::FormulaProfile& profile);
extern "C" bool lymphosat_match_matcher_125_xor_op(const lymphosat::FormulaProfile& profile);

namespace lymphosat {
const std::vector<MatcherEntry>& matcher_registry() {
    static const std::vector<MatcherEntry> entries = {
        {"01-integer-programming", "solvers/01-integer-programming/solver/solver", &lymphosat_match_matcher_0__01_integer_programming},
        {"algebra", "solvers/algebra/solver/solver", &lymphosat_match_matcher_1_algebra},
        {"algorithm-equivalence-checking", "solvers/algorithm-equivalence-checking/solver/solver", &lymphosat_match_matcher_2_algorithm_equivalence_checking},
        {"alloy-vpn-models", "solvers/alloy-vpn-models/solver/solver", &lymphosat_match_matcher_3_alloy_vpn_models},
        {"antibandwidth", "solvers/antibandwidth/solver/solver", &lymphosat_match_matcher_4_antibandwidth},
        {"auto-correlation", "solvers/auto-correlation/solver/solver", &lymphosat_match_matcher_5_auto_correlation},
        {"automata-synchronization", "solvers/automata-synchronization/solver/solver", &lymphosat_match_matcher_6_automata_synchronization},
        {"battleship", "solvers/battleship/solver/solver", &lymphosat_match_matcher_7_battleship},
        {"binary-pigeon-hole", "solvers/binary-pigeon-hole/solver/solver", &lymphosat_match_matcher_8_binary_pigeon_hole},
        {"binary-tree-parity", "solvers/binary-tree-parity/solver/solver", &lymphosat_match_matcher_9_binary_tree_parity},
        {"brent-equations", "solvers/brent-equations/solver/solver", &lymphosat_match_matcher_10_brent_equations},
        {"circuit-equialence-checking", "solvers/circuit-equialence-checking/solver/solver", &lymphosat_match_matcher_11_circuit_equialence_checking},
        {"circuit-minimization", "solvers/circuit-minimization/solver/solver", &lymphosat_match_matcher_12_circuit_minimization},
        {"clique-coloring", "solvers/clique-coloring/solver/solver", &lymphosat_match_matcher_13_clique_coloring},
        {"clique-formulas", "solvers/clique-formulas/solver/solver", &lymphosat_match_matcher_14_clique_formulas},
        {"clique-width", "solvers/clique-width/solver/solver", &lymphosat_match_matcher_15_clique_width},
        {"clustered-random", "solvers/clustered-random/solver/solver", &lymphosat_match_matcher_16_clustered_random},
        {"coloring-clique", "solvers/coloring-clique/solver/solver", &lymphosat_match_matcher_17_coloring_clique},
        {"coloring-mycielski-graph", "solvers/coloring-mycielski-graph/solver/solver", &lymphosat_match_matcher_18_coloring_mycielski_graph},
        {"core-based-generator", "solvers/core-based-generator/solver/solver", &lymphosat_match_matcher_19_core_based_generator},
        {"cover", "solvers/cover/solver/solver", &lymphosat_match_matcher_20_cover},
        {"cryptography-ascon", "solvers/cryptography-ascon/solver/solver", &lymphosat_match_matcher_21_cryptography_ascon},
        {"cryptography-cbmc", "solvers/cryptography-cbmc/solver/solver", &lymphosat_match_matcher_22_cryptography_cbmc},
        {"cryptography-simon", "solvers/cryptography-simon/solver/solver", &lymphosat_match_matcher_23_cryptography_simon},
        {"design-debugging", "solvers/design-debugging/solver/solver", &lymphosat_match_matcher_24_design_debugging},
        {"diagnosis", "solvers/diagnosis/solver/solver", &lymphosat_match_matcher_25_diagnosis},
        {"discrete-logarithm", "solvers/discrete-logarithm/solver/solver", &lymphosat_match_matcher_26_discrete_logarithm},
        {"edge-matching", "solvers/edge-matching/solver/solver", &lymphosat_match_matcher_27_edge_matching},
        {"edit-distance", "solvers/edit-distance/solver/solver", &lymphosat_match_matcher_28_edit_distance},
        {"equivalence-chain-principle", "solvers/equivalence-chain-principle/solver/solver", &lymphosat_match_matcher_29_equivalence_chain_principle},
        {"erdos-discrepancy", "solvers/erdos-discrepancy/solver/solver", &lymphosat_match_matcher_30_erdos_discrepancy},
        {"fdmus", "solvers/fdmus/solver/solver", &lymphosat_match_matcher_31_fdmus},
        {"fermat", "solvers/fermat/solver/solver", &lymphosat_match_matcher_32_fermat},
        {"fixed-shape-random", "solvers/fixed-shape-random/solver/solver", &lymphosat_match_matcher_33_fixed_shape_random},
        {"floodit-puzzle", "solvers/floodit-puzzle/solver/solver", &lymphosat_match_matcher_34_floodit_puzzle},
        {"fpga-routing", "solvers/fpga-routing/solver/solver", &lymphosat_match_matcher_35_fpga_routing},
        {"genurq", "solvers/genurq/solver/solver", &lymphosat_match_matcher_36_genurq},
        {"gf3-sat", "solvers/gf3-sat/solver/solver", &lymphosat_match_matcher_37_gf3_sat},
        {"glassy-gen", "solvers/glassy-gen/solver/solver", &lymphosat_match_matcher_38_glassy_gen},
        {"graceful-production", "solvers/graceful-production/solver/solver", &lymphosat_match_matcher_39_graceful_production},
        {"grandtour-puzzle", "solvers/grandtour-puzzle/solver/solver", &lymphosat_match_matcher_40_grandtour_puzzle},
        {"greentao", "solvers/greentao/solver/solver", &lymphosat_match_matcher_41_greentao},
        {"hamiltonian-cycle", "solvers/hamiltonian-cycle/solver/solver", &lymphosat_match_matcher_42_hamiltonian_cycle},
        {"hanoi", "solvers/hanoi/solver/solver", &lymphosat_match_matcher_43_hanoi},
        {"heule-nol", "solvers/heule-nol/solver/solver", &lymphosat_match_matcher_44_heule_nol},
        {"hgen", "solvers/hgen/solver/solver", &lymphosat_match_matcher_45_hgen},
        {"hidoku", "solvers/hidoku/solver/solver", &lymphosat_match_matcher_46_hidoku},
        {"hypertree-decomposition", "solvers/hypertree-decomposition/solver/solver", &lymphosat_match_matcher_47_hypertree_decomposition},
        {"independent-set", "solvers/independent-set/solver/solver", &lymphosat_match_matcher_48_independent_set},
        {"independent-set-reconfiguration", "solvers/independent-set-reconfiguration/solver/solver", &lymphosat_match_matcher_49_independent_set_reconfiguration},
        {"influence-maximization", "solvers/influence-maximization/solver/solver", &lymphosat_match_matcher_50_influence_maximization},
        {"interval-matching", "solvers/interval-matching/solver/solver", &lymphosat_match_matcher_51_interval_matching},
        {"karatsuba-multiplication", "solvers/karatsuba-multiplication/solver/solver", &lymphosat_match_matcher_52_karatsuba_multiplication},
        {"knights-problem", "solvers/knights-problem/solver/solver", &lymphosat_match_matcher_53_knights_problem},
        {"ktf", "solvers/ktf/solver/solver", &lymphosat_match_matcher_54_ktf},
        {"long-learned-clauses", "solvers/long-learned-clauses/solver/solver", &lymphosat_match_matcher_55_long_learned_clauses},
        {"maximum-constraint-partition", "solvers/maximum-constraint-partition/solver/solver", &lymphosat_match_matcher_56_maximum_constraint_partition},
        {"md5-equivalence-checking", "solvers/md5-equivalence-checking/solver/solver", &lymphosat_match_matcher_57_md5_equivalence_checking},
        {"mechanical-master-key", "solvers/mechanical-master-key/solver/solver", &lymphosat_match_matcher_58_mechanical_master_key},
        {"minimal-superpermutation", "solvers/minimal-superpermutation/solver/solver", &lymphosat_match_matcher_59_minimal_superpermutation},
        {"minimum-disagreement-parity", "solvers/minimum-disagreement-parity/solver/solver", &lymphosat_match_matcher_60_minimum_disagreement_parity},
        {"modcircuits", "solvers/modcircuits/solver/solver", &lymphosat_match_matcher_61_modcircuits},
        {"mosoi-289", "solvers/mosoi-289/solver/solver", &lymphosat_match_matcher_62_mosoi_289},
        {"multiplier-circuits", "solvers/multiplier-circuits/solver/solver", &lymphosat_match_matcher_63_multiplier_circuits},
        {"multiplier-verification", "solvers/multiplier-verification/solver/solver", &lymphosat_match_matcher_64_multiplier_verification},
        {"mutilated-chessboard", "solvers/mutilated-chessboard/solver/solver", &lymphosat_match_matcher_65_mutilated_chessboard},
        {"oddball-weighing", "solvers/oddball-weighing/solver/solver", &lymphosat_match_matcher_66_oddball_weighing},
        {"or_randxor", "solvers/or_randxor/solver/solver", &lymphosat_match_matcher_67_or_randxor},
        {"ordering-principle", "solvers/ordering-principle/solver/solver", &lymphosat_match_matcher_68_ordering_principle},
        {"ordering-principle-xor", "solvers/ordering-principle-xor/solver/solver", &lymphosat_match_matcher_69_ordering_principle_xor},
        {"p-center", "solvers/p-center/solver/solver", &lymphosat_match_matcher_70_p_center},
        {"pebbling", "solvers/pebbling/solver/solver", &lymphosat_match_matcher_71_pebbling},
        {"petrinet-concurrency", "solvers/petrinet-concurrency/solver/solver", &lymphosat_match_matcher_72_petrinet_concurrency},
        {"philips", "solvers/philips/solver/solver", &lymphosat_match_matcher_73_philips},
        {"phnf", "solvers/phnf/solver/solver", &lymphosat_match_matcher_74_phnf},
        {"pigeon-hole", "solvers/pigeon-hole/solver/solver", &lymphosat_match_matcher_75_pigeon_hole},
        {"planning", "solvers/planning/solver/solver", &lymphosat_match_matcher_76_planning},
        {"product-configuration", "solvers/product-configuration/solver/solver", &lymphosat_match_matcher_77_product_configuration},
        {"profitable-robust-production", "solvers/profitable-robust-production/solver/solver", &lymphosat_match_matcher_78_profitable_robust_production},
        {"purdom-instances", "solvers/purdom-instances/solver/solver", &lymphosat_match_matcher_79_purdom_instances},
        {"pythagorean-triples", "solvers/pythagorean-triples/solver/solver", &lymphosat_match_matcher_80_pythagorean_triples},
        {"railway-safety", "solvers/railway-safety/solver/solver", &lymphosat_match_matcher_81_railway_safety},
        {"ramsey", "solvers/ramsey/solver/solver", &lymphosat_match_matcher_82_ramsey},
        {"ramsey-numbers", "solvers/ramsey-numbers/solver/solver", &lymphosat_match_matcher_83_ramsey_numbers},
        {"ramseycube", "solvers/ramseycube/solver/solver", &lymphosat_match_matcher_84_ramseycube},
        {"random", "solvers/random/solver/solver", &lymphosat_match_matcher_85_random},
        {"random-circuits", "solvers/random-circuits/solver/solver", &lymphosat_match_matcher_86_random_circuits},
        {"random-clustered", "solvers/random-clustered/solver/solver", &lymphosat_match_matcher_87_random_clustered},
        {"random-csp", "solvers/random-csp/solver/solver", &lymphosat_match_matcher_88_random_csp},
        {"random-mus", "solvers/random-mus/solver/solver", &lymphosat_match_matcher_89_random_mus},
        {"random-planted-solution", "solvers/random-planted-solution/solver/solver", &lymphosat_match_matcher_90_random_planted_solution},
        {"rbsat", "solvers/rbsat/solver/solver", &lymphosat_match_matcher_91_rbsat},
        {"register-allocation", "solvers/register-allocation/solver/solver", &lymphosat_match_matcher_92_register_allocation},
        {"relational-dependencies", "solvers/relational-dependencies/solver/solver", &lymphosat_match_matcher_93_relational_dependencies},
        {"relativized-pigeon-hole", "solvers/relativized-pigeon-hole/solver/solver", &lymphosat_match_matcher_94_relativized_pigeon_hole},
        {"rooks", "solvers/rooks/solver/solver", &lymphosat_match_matcher_95_rooks},
        {"sat-x", "solvers/sat-x/solver/solver", &lymphosat_match_matcher_96_sat_x},
        {"satcoin", "solvers/satcoin/solver/solver", &lymphosat_match_matcher_97_satcoin},
        {"set-covering", "solvers/set-covering/solver/solver", &lymphosat_match_matcher_98_set_covering},
        {"sgen", "solvers/sgen/solver/solver", &lymphosat_match_matcher_99_sgen},
        {"sgen-balanced", "solvers/sgen-balanced/solver/solver", &lymphosat_match_matcher_100_sgen_balanced},
        {"sliding-puzzle", "solvers/sliding-puzzle/solver/solver", &lymphosat_match_matcher_101_sliding_puzzle},
        {"social-golfer", "solvers/social-golfer/solver/solver", &lymphosat_match_matcher_102_social_golfer},
        {"software-bmc", "solvers/software-bmc/solver/solver", &lymphosat_match_matcher_103_software_bmc},
        {"software-verification", "solvers/software-verification/solver/solver", &lymphosat_match_matcher_104_software_verification},
        {"sorting-networks", "solvers/sorting-networks/solver/solver", &lymphosat_match_matcher_105_sorting_networks},
        {"ssp-0", "solvers/ssp-0/solver/solver", &lymphosat_match_matcher_106_ssp_0},
        {"st-connectivity-principle", "solvers/st-connectivity-principle/solver/solver", &lymphosat_match_matcher_107_st_connectivity_principle},
        {"station-repacking", "solvers/station-repacking/solver/solver", &lymphosat_match_matcher_108_station_repacking},
        {"stedman-triples", "solvers/stedman-triples/solver/solver", &lymphosat_match_matcher_109_stedman_triples},
        {"stone", "solvers/stone/solver/solver", &lymphosat_match_matcher_110_stone},
        {"subgraph-isomorphism", "solvers/subgraph-isomorphism/solver/solver", &lymphosat_match_matcher_111_subgraph_isomorphism},
        {"subsumptiontest", "solvers/subsumptiontest/solver/solver", &lymphosat_match_matcher_112_subsumptiontest},
        {"sum-of-3-cubes", "solvers/sum-of-3-cubes/solver/solver", &lymphosat_match_matcher_113_sum_of_3_cubes},
        {"summle", "solvers/summle/solver/solver", &lymphosat_match_matcher_114_summle},
        {"tensors", "solvers/tensors/solver/solver", &lymphosat_match_matcher_115_tensors},
        {"test-configuration", "solvers/test-configuration/solver/solver", &lymphosat_match_matcher_116_test_configuration},
        {"testpattern-generation", "solvers/testpattern-generation/solver/solver", &lymphosat_match_matcher_117_testpattern_generation},
        {"theorem-proving", "solvers/theorem-proving/solver/solver", &lymphosat_match_matcher_118_theorem_proving},
        {"tree-decomposition", "solvers/tree-decomposition/solver/solver", &lymphosat_match_matcher_119_tree_decomposition},
        {"trigonometric-functions", "solvers/trigonometric-functions/solver/solver", &lymphosat_match_matcher_120_trigonometric_functions},
        {"tseitin-formulas", "solvers/tseitin-formulas/solver/solver", &lymphosat_match_matcher_121_tseitin_formulas},
        {"uniform-random", "solvers/uniform-random/solver/solver", &lymphosat_match_matcher_122_uniform_random},
        {"waerden", "solvers/waerden/solver/solver", &lymphosat_match_matcher_123_waerden},
        {"xor-chain", "solvers/xor-chain/solver/solver", &lymphosat_match_matcher_124_xor_chain},
        {"xor_op", "solvers/xor_op/solver/solver", &lymphosat_match_matcher_125_xor_op},
    };
    return entries;
}

const char* fallback_solver_name() {
    return "fallback";
}
}  // namespace lymphosat
