file(REMOVE_RECURSE
  "CMakeFiles/matcher_obj_27_edge_matching.dir/solvers/edge-matching/matcher/match.cpp.o"
  "CMakeFiles/matcher_obj_27_edge_matching.dir/solvers/edge-matching/matcher/match.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/matcher_obj_27_edge_matching.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
