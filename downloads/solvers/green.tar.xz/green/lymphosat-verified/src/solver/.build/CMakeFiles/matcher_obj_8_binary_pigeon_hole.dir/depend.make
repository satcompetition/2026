# Empty dependencies file for matcher_obj_8_binary_pigeon_hole.
# This may be replaced when dependencies are built.
