# Empty dependencies file for matcher_obj_111_subgraph_isomorphism.
# This may be replaced when dependencies are built.
