# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for matcher_obj_17_coloring_clique.
