# Empty dependencies file for matcher_obj_88_random_csp.
# This may be replaced when dependencies are built.
