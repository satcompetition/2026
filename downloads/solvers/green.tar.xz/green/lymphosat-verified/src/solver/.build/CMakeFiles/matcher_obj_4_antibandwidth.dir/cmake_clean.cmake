file(REMOVE_RECURSE
  "CMakeFiles/matcher_obj_4_antibandwidth.dir/solvers/antibandwidth/matcher/match.cpp.o"
  "CMakeFiles/matcher_obj_4_antibandwidth.dir/solvers/antibandwidth/matcher/match.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/matcher_obj_4_antibandwidth.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
