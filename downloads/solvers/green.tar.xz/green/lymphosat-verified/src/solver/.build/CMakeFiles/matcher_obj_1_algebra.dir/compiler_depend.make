# Empty compiler generated dependencies file for matcher_obj_1_algebra.
# This may be replaced when dependencies are built.
