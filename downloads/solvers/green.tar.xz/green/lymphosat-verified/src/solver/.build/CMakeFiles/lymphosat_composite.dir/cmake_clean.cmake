file(REMOVE_RECURSE
  "/home/iser/Documents/satcomp/satcomp2026/solvers/green/lymphosat-verified/src/solver/solver"
  "/home/iser/Documents/satcomp/satcomp2026/solvers/green/lymphosat-verified/src/solver/solver.pdb"
  "CMakeFiles/lymphosat_composite.dir/core/main.cpp.o"
  "CMakeFiles/lymphosat_composite.dir/core/main.cpp.o.d"
  "CMakeFiles/lymphosat_composite.dir/core/profiler.cpp.o"
  "CMakeFiles/lymphosat_composite.dir/core/profiler.cpp.o.d"
  "CMakeFiles/lymphosat_composite.dir/matcher_registry.cpp.o"
  "CMakeFiles/lymphosat_composite.dir/matcher_registry.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/lymphosat_composite.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
