# Empty dependencies file for matcher_obj_120_trigonometric_functions.
# This may be replaced when dependencies are built.
