# Empty compiler generated dependencies file for matcher_obj_16_clustered_random.
# This may be replaced when dependencies are built.
