file(REMOVE_RECURSE
  "CMakeFiles/matcher_obj_113_sum_of_3_cubes.dir/solvers/sum-of-3-cubes/matcher/match.cpp.o"
  "CMakeFiles/matcher_obj_113_sum_of_3_cubes.dir/solvers/sum-of-3-cubes/matcher/match.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/matcher_obj_113_sum_of_3_cubes.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
