#!/bin/sh
cd build
exec ./build.sh
