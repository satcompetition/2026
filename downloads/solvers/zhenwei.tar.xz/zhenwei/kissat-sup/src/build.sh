#!/bin/sh
mkdir -p build
# sup
cd sup
CC=gcc ./configure --no-proofs -flto -fno-strict-aliasing
make all || exit 1
install -s build/kissat ../build/sup
cd ..
# breakid
cd breakid/src
make CXX=g++ LDFLAGS="" all || exit 1
install -s BreakID ../../build/breakid
cd ../..
# kmpsym
cd kmpsym
make -C bliss lib || exit 1   # builds libbliss.a, needed by kmpsym at link time
rm -f makefile
CC=gcc ./configure -flto -fno-strict-aliasing
make all || exit 1
install -s build/kissat ../build/kmpsym
cd ..
