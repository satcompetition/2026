#!/bin/bash
# run-parsl.sh — call binary directly (solver: kissat-sup)
# Usage: ./run-parsl.sh <cnf> <proof_output_file>
cd "$(dirname "$0")"
CNF="$1"
./build/kmpsym --relaxed "$CNF" | ./build/breakid -v 0 -t 100 -s 100 -no-bin -no-relaxed | ./build/sup -q --relaxed
