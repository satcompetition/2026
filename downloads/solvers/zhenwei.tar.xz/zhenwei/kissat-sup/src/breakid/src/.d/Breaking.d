obj/Breaking.o: Breaking.cpp Breaking.hpp global.hpp Algebraic.hpp \
 Theory.hpp boost/multiprecision/gmp.hpp \
 boost/multiprecision/detail/standalone_config.hpp boost/config.hpp \
 boost/config/user.hpp boost/config/detail/select_compiler_config.hpp \
 boost/config/compiler/gcc.hpp \
 boost/config/detail/select_stdlib_config.hpp \
 boost/config/stdlib/libstdcpp3.hpp \
 boost/config/detail/select_platform_config.hpp \
 boost/config/platform/linux.hpp boost/config/detail/posix_features.hpp \
 boost/config/detail/suffix.hpp boost/config/workaround.hpp \
 boost/integer.hpp boost/integer_fwd.hpp boost/limits.hpp \
 boost/cstdint.hpp boost/integer_traits.hpp boost/static_assert.hpp \
 boost/detail/workaround.hpp boost/multiprecision/number.hpp \
 boost/multiprecision/detail/precision.hpp \
 boost/multiprecision/traits/is_variable_precision.hpp \
 boost/multiprecision/detail/number_base.hpp boost/multiprecision/fwd.hpp \
 boost/multiprecision/cpp_int/cpp_int_config.hpp \
 boost/multiprecision/detail/assert.hpp boost/assert.hpp \
 boost/multiprecision/traits/transcendental_reduction_type.hpp \
 boost/multiprecision/traits/std_integer_traits.hpp \
 boost/multiprecision/detail/no_exceptions_support.hpp \
 boost/core/no_exceptions_support.hpp boost/throw_exception.hpp \
 boost/exception/exception.hpp boost/assert/source_location.hpp \
 boost/lexical_cast.hpp boost/lexical_cast/detail/buffer_view.hpp \
 boost/lexical_cast/bad_lexical_cast.hpp \
 boost/lexical_cast/try_lexical_convert.hpp \
 boost/type_traits/conditional.hpp boost/type_traits/is_arithmetic.hpp \
 boost/type_traits/is_integral.hpp \
 boost/type_traits/integral_constant.hpp \
 boost/type_traits/is_floating_point.hpp \
 boost/lexical_cast/detail/is_character.hpp boost/type_traits/is_same.hpp \
 boost/lexical_cast/detail/converter_numeric.hpp boost/core/cmath.hpp \
 boost/core/enable_if.hpp boost/type_traits/type_identity.hpp \
 boost/type_traits/make_unsigned.hpp boost/type_traits/is_signed.hpp \
 boost/type_traits/remove_cv.hpp boost/type_traits/is_enum.hpp \
 boost/type_traits/intrinsics.hpp boost/type_traits/detail/config.hpp \
 boost/version.hpp boost/type_traits/is_unsigned.hpp \
 boost/type_traits/is_const.hpp boost/type_traits/is_volatile.hpp \
 boost/type_traits/add_const.hpp boost/type_traits/add_volatile.hpp \
 boost/type_traits/is_float.hpp \
 boost/lexical_cast/detail/converter_lexical.hpp \
 boost/detail/lcast_precision.hpp \
 boost/lexical_cast/detail/widest_char.hpp \
 boost/container/container_fwd.hpp boost/container/detail/std_fwd.hpp \
 boost/move/detail/std_ns_begin.hpp boost/move/detail/std_ns_end.hpp \
 boost/lexical_cast/detail/converter_lexical_streams.hpp \
 boost/type_traits/is_pointer.hpp boost/core/snprintf.hpp \
 boost/lexical_cast/detail/lcast_char_constants.hpp \
 boost/lexical_cast/detail/lcast_unsigned_converters.hpp \
 boost/core/noncopyable.hpp \
 boost/lexical_cast/detail/lcast_basic_unlockedbuf.hpp \
 boost/detail/basic_pointerbuf.hpp boost/lexical_cast/detail/inf_nan.hpp \
 boost/type_traits/is_reference.hpp \
 boost/type_traits/is_lvalue_reference.hpp \
 boost/type_traits/is_rvalue_reference.hpp boost/core/nvp.hpp \
 boost/core/addressof.hpp boost/math/tools/complex.hpp \
 boost/math/tools/is_detected.hpp \
 boost/multiprecision/detail/check_cpp11_config.hpp \
 boost/multiprecision/detail/digits.hpp \
 boost/multiprecision/detail/generic_interconvert.hpp \
 boost/multiprecision/detail/default_ops.hpp \
 boost/multiprecision/traits/is_backend.hpp \
 boost/multiprecision/detail/fpclassify.hpp \
 boost/multiprecision/detail/float128_functions.hpp boost/cstdfloat.hpp \
 boost/math/cstdfloat/cstdfloat_types.hpp boost/math/tools/config.hpp \
 boost/math/tools/is_standalone.hpp boost/math/tools/user.hpp \
 boost/math/cstdfloat/cstdfloat_limits.hpp \
 boost/math/cstdfloat/cstdfloat_cmath.hpp \
 boost/math/cstdfloat/cstdfloat_iostream.hpp \
 boost/math/cstdfloat/cstdfloat_complex.hpp \
 boost/math/special_functions/fpclassify.hpp \
 boost/math/tools/real_cast.hpp boost/math/special_functions/math_fwd.hpp \
 boost/math/special_functions/detail/round_fwd.hpp \
 boost/math/tools/promotion.hpp boost/math/policies/policy.hpp \
 boost/math/tools/mp.hpp \
 boost/math/special_functions/detail/fp_traits.hpp \
 boost/math/tools/assert.hpp boost/predef/other/endian.h \
 boost/predef/version_number.h boost/predef/make.h \
 boost/predef/detail/test.h boost/predef/library/c/gnu.h \
 boost/predef/library/c/_prefix.h boost/predef/detail/_cassert.h \
 boost/predef/os/macos.h boost/predef/os/ios.h boost/predef/os/bsd.h \
 boost/predef/os/bsd/bsdi.h boost/predef/os/bsd/dragonfly.h \
 boost/predef/os/bsd/free.h boost/predef/os/bsd/open.h \
 boost/predef/os/bsd/net.h boost/predef/platform/android.h \
 boost/math/special_functions/next.hpp \
 boost/math/policies/error_handling.hpp boost/math/tools/precision.hpp \
 boost/math/tools/throw_exception.hpp \
 boost/math/special_functions/sign.hpp \
 boost/math/special_functions/trunc.hpp \
 boost/math/ccmath/detail/config.hpp \
 boost/math/tools/is_constant_evaluated.hpp boost/math/tools/traits.hpp \
 boost/math/special_functions/hypot.hpp \
 boost/multiprecision/detail/functions/constants.hpp \
 boost/multiprecision/detail/functions/pow.hpp \
 boost/multiprecision/detail/functions/trig.hpp \
 boost/multiprecision/detail/no_et_ops.hpp \
 boost/multiprecision/detail/et_ops.hpp \
 boost/multiprecision/detail/min_max.hpp \
 boost/multiprecision/detail/functions/trunc.hpp \
 boost/multiprecision/detail/number_compare.hpp \
 boost/multiprecision/traits/is_restricted_conversion.hpp \
 boost/multiprecision/traits/explicit_conversion.hpp \
 boost/multiprecision/traits/is_complex.hpp \
 boost/multiprecision/traits/is_convertible_arithmetic.hpp \
 boost/multiprecision/detail/hash.hpp \
 boost/multiprecision/detail/ublas_interop.hpp \
 boost/multiprecision/debug_adaptor.hpp \
 boost/multiprecision/traits/extract_exponent_type.hpp \
 boost/multiprecision/detail/integer_ops.hpp \
 boost/multiprecision/detail/atomic.hpp \
 boost/multiprecision/detail/string_helpers.hpp \
 boost/math/special_functions/asinh.hpp \
 boost/math/special_functions/sqrt1pm1.hpp \
 boost/math/special_functions/log1p.hpp boost/math/tools/series.hpp \
 boost/math/tools/rational.hpp \
 boost/math/tools/detail/polynomial_horner3_20.hpp \
 boost/math/tools/detail/rational_horner3_20.hpp \
 boost/math/tools/big_constant.hpp boost/math/special_functions/expm1.hpp \
 boost/math/constants/constants.hpp boost/math/tools/cxx03_warn.hpp \
 boost/math/tools/convert_from_string.hpp \
 boost/math/constants/calculate_constants.hpp \
 boost/math/special_functions/acosh.hpp \
 boost/math/special_functions/atanh.hpp \
 boost/math/special_functions/cbrt.hpp \
 boost/math/special_functions/gamma.hpp boost/math/tools/fraction.hpp \
 boost/math/special_functions/powm1.hpp \
 boost/math/special_functions/lanczos.hpp \
 boost/math/special_functions/detail/lanczos_sse2.hpp \
 boost/math/special_functions/detail/igamma_large.hpp \
 boost/math/special_functions/detail/unchecked_factorial.hpp \
 boost/math/special_functions/detail/lgamma_small.hpp \
 boost/math/special_functions/bernoulli.hpp \
 boost/math/special_functions/detail/unchecked_bernoulli.hpp \
 boost/math/special_functions/detail/bernoulli_details.hpp \
 boost/math/tools/atomic.hpp boost/math/tools/toms748_solve.hpp \
 boost/math/special_functions/polygamma.hpp \
 boost/math/special_functions/factorials.hpp \
 boost/math/special_functions/detail/polygamma.hpp \
 boost/math/special_functions/zeta.hpp \
 boost/math/special_functions/sin_pi.hpp \
 boost/math/special_functions/digamma.hpp \
 boost/math/special_functions/cos_pi.hpp \
 boost/math/special_functions/pow.hpp \
 boost/math/special_functions/trigamma.hpp \
 boost/math/special_functions/detail/igamma_inverse.hpp \
 boost/math/tools/tuple.hpp boost/math/tools/roots.hpp \
 boost/math/special_functions/detail/gamma_inva.hpp \
 boost/math/special_functions/erf.hpp \
 boost/math/special_functions/detail/erf_inv.hpp
Breaking.hpp:
global.hpp:
Algebraic.hpp:
Theory.hpp:
boost/multiprecision/gmp.hpp:
boost/multiprecision/detail/standalone_config.hpp:
boost/config.hpp:
boost/config/user.hpp:
boost/config/detail/select_compiler_config.hpp:
boost/config/compiler/gcc.hpp:
boost/config/detail/select_stdlib_config.hpp:
boost/config/stdlib/libstdcpp3.hpp:
boost/config/detail/select_platform_config.hpp:
boost/config/platform/linux.hpp:
boost/config/detail/posix_features.hpp:
boost/config/detail/suffix.hpp:
boost/config/workaround.hpp:
boost/integer.hpp:
boost/integer_fwd.hpp:
boost/limits.hpp:
boost/cstdint.hpp:
boost/integer_traits.hpp:
boost/static_assert.hpp:
boost/detail/workaround.hpp:
boost/multiprecision/number.hpp:
boost/multiprecision/detail/precision.hpp:
boost/multiprecision/traits/is_variable_precision.hpp:
boost/multiprecision/detail/number_base.hpp:
boost/multiprecision/fwd.hpp:
boost/multiprecision/cpp_int/cpp_int_config.hpp:
boost/multiprecision/detail/assert.hpp:
boost/assert.hpp:
boost/multiprecision/traits/transcendental_reduction_type.hpp:
boost/multiprecision/traits/std_integer_traits.hpp:
boost/multiprecision/detail/no_exceptions_support.hpp:
boost/core/no_exceptions_support.hpp:
boost/throw_exception.hpp:
boost/exception/exception.hpp:
boost/assert/source_location.hpp:
boost/lexical_cast.hpp:
boost/lexical_cast/detail/buffer_view.hpp:
boost/lexical_cast/bad_lexical_cast.hpp:
boost/lexical_cast/try_lexical_convert.hpp:
boost/type_traits/conditional.hpp:
boost/type_traits/is_arithmetic.hpp:
boost/type_traits/is_integral.hpp:
boost/type_traits/integral_constant.hpp:
boost/type_traits/is_floating_point.hpp:
boost/lexical_cast/detail/is_character.hpp:
boost/type_traits/is_same.hpp:
boost/lexical_cast/detail/converter_numeric.hpp:
boost/core/cmath.hpp:
boost/core/enable_if.hpp:
boost/type_traits/type_identity.hpp:
boost/type_traits/make_unsigned.hpp:
boost/type_traits/is_signed.hpp:
boost/type_traits/remove_cv.hpp:
boost/type_traits/is_enum.hpp:
boost/type_traits/intrinsics.hpp:
boost/type_traits/detail/config.hpp:
boost/version.hpp:
boost/type_traits/is_unsigned.hpp:
boost/type_traits/is_const.hpp:
boost/type_traits/is_volatile.hpp:
boost/type_traits/add_const.hpp:
boost/type_traits/add_volatile.hpp:
boost/type_traits/is_float.hpp:
boost/lexical_cast/detail/converter_lexical.hpp:
boost/detail/lcast_precision.hpp:
boost/lexical_cast/detail/widest_char.hpp:
boost/container/container_fwd.hpp:
boost/container/detail/std_fwd.hpp:
boost/move/detail/std_ns_begin.hpp:
boost/move/detail/std_ns_end.hpp:
boost/lexical_cast/detail/converter_lexical_streams.hpp:
boost/type_traits/is_pointer.hpp:
boost/core/snprintf.hpp:
boost/lexical_cast/detail/lcast_char_constants.hpp:
boost/lexical_cast/detail/lcast_unsigned_converters.hpp:
boost/core/noncopyable.hpp:
boost/lexical_cast/detail/lcast_basic_unlockedbuf.hpp:
boost/detail/basic_pointerbuf.hpp:
boost/lexical_cast/detail/inf_nan.hpp:
boost/type_traits/is_reference.hpp:
boost/type_traits/is_lvalue_reference.hpp:
boost/type_traits/is_rvalue_reference.hpp:
boost/core/nvp.hpp:
boost/core/addressof.hpp:
boost/math/tools/complex.hpp:
boost/math/tools/is_detected.hpp:
boost/multiprecision/detail/check_cpp11_config.hpp:
boost/multiprecision/detail/digits.hpp:
boost/multiprecision/detail/generic_interconvert.hpp:
boost/multiprecision/detail/default_ops.hpp:
boost/multiprecision/traits/is_backend.hpp:
boost/multiprecision/detail/fpclassify.hpp:
boost/multiprecision/detail/float128_functions.hpp:
boost/cstdfloat.hpp:
boost/math/cstdfloat/cstdfloat_types.hpp:
boost/math/tools/config.hpp:
boost/math/tools/is_standalone.hpp:
boost/math/tools/user.hpp:
boost/math/cstdfloat/cstdfloat_limits.hpp:
boost/math/cstdfloat/cstdfloat_cmath.hpp:
boost/math/cstdfloat/cstdfloat_iostream.hpp:
boost/math/cstdfloat/cstdfloat_complex.hpp:
boost/math/special_functions/fpclassify.hpp:
boost/math/tools/real_cast.hpp:
boost/math/special_functions/math_fwd.hpp:
boost/math/special_functions/detail/round_fwd.hpp:
boost/math/tools/promotion.hpp:
boost/math/policies/policy.hpp:
boost/math/tools/mp.hpp:
boost/math/special_functions/detail/fp_traits.hpp:
boost/math/tools/assert.hpp:
boost/predef/other/endian.h:
boost/predef/version_number.h:
boost/predef/make.h:
boost/predef/detail/test.h:
boost/predef/library/c/gnu.h:
boost/predef/library/c/_prefix.h:
boost/predef/detail/_cassert.h:
boost/predef/os/macos.h:
boost/predef/os/ios.h:
boost/predef/os/bsd.h:
boost/predef/os/bsd/bsdi.h:
boost/predef/os/bsd/dragonfly.h:
boost/predef/os/bsd/free.h:
boost/predef/os/bsd/open.h:
boost/predef/os/bsd/net.h:
boost/predef/platform/android.h:
boost/math/special_functions/next.hpp:
boost/math/policies/error_handling.hpp:
boost/math/tools/precision.hpp:
boost/math/tools/throw_exception.hpp:
boost/math/special_functions/sign.hpp:
boost/math/special_functions/trunc.hpp:
boost/math/ccmath/detail/config.hpp:
boost/math/tools/is_constant_evaluated.hpp:
boost/math/tools/traits.hpp:
boost/math/special_functions/hypot.hpp:
boost/multiprecision/detail/functions/constants.hpp:
boost/multiprecision/detail/functions/pow.hpp:
boost/multiprecision/detail/functions/trig.hpp:
boost/multiprecision/detail/no_et_ops.hpp:
boost/multiprecision/detail/et_ops.hpp:
boost/multiprecision/detail/min_max.hpp:
boost/multiprecision/detail/functions/trunc.hpp:
boost/multiprecision/detail/number_compare.hpp:
boost/multiprecision/traits/is_restricted_conversion.hpp:
boost/multiprecision/traits/explicit_conversion.hpp:
boost/multiprecision/traits/is_complex.hpp:
boost/multiprecision/traits/is_convertible_arithmetic.hpp:
boost/multiprecision/detail/hash.hpp:
boost/multiprecision/detail/ublas_interop.hpp:
boost/multiprecision/debug_adaptor.hpp:
boost/multiprecision/traits/extract_exponent_type.hpp:
boost/multiprecision/detail/integer_ops.hpp:
boost/multiprecision/detail/atomic.hpp:
boost/multiprecision/detail/string_helpers.hpp:
boost/math/special_functions/asinh.hpp:
boost/math/special_functions/sqrt1pm1.hpp:
boost/math/special_functions/log1p.hpp:
boost/math/tools/series.hpp:
boost/math/tools/rational.hpp:
boost/math/tools/detail/polynomial_horner3_20.hpp:
boost/math/tools/detail/rational_horner3_20.hpp:
boost/math/tools/big_constant.hpp:
boost/math/special_functions/expm1.hpp:
boost/math/constants/constants.hpp:
boost/math/tools/cxx03_warn.hpp:
boost/math/tools/convert_from_string.hpp:
boost/math/constants/calculate_constants.hpp:
boost/math/special_functions/acosh.hpp:
boost/math/special_functions/atanh.hpp:
boost/math/special_functions/cbrt.hpp:
boost/math/special_functions/gamma.hpp:
boost/math/tools/fraction.hpp:
boost/math/special_functions/powm1.hpp:
boost/math/special_functions/lanczos.hpp:
boost/math/special_functions/detail/lanczos_sse2.hpp:
boost/math/special_functions/detail/igamma_large.hpp:
boost/math/special_functions/detail/unchecked_factorial.hpp:
boost/math/special_functions/detail/lgamma_small.hpp:
boost/math/special_functions/bernoulli.hpp:
boost/math/special_functions/detail/unchecked_bernoulli.hpp:
boost/math/special_functions/detail/bernoulli_details.hpp:
boost/math/tools/atomic.hpp:
boost/math/tools/toms748_solve.hpp:
boost/math/special_functions/polygamma.hpp:
boost/math/special_functions/factorials.hpp:
boost/math/special_functions/detail/polygamma.hpp:
boost/math/special_functions/zeta.hpp:
boost/math/special_functions/sin_pi.hpp:
boost/math/special_functions/digamma.hpp:
boost/math/special_functions/cos_pi.hpp:
boost/math/special_functions/pow.hpp:
boost/math/special_functions/trigamma.hpp:
boost/math/special_functions/detail/igamma_inverse.hpp:
boost/math/tools/tuple.hpp:
boost/math/tools/roots.hpp:
boost/math/special_functions/detail/gamma_inva.hpp:
boost/math/special_functions/erf.hpp:
boost/math/special_functions/detail/erf_inv.hpp:
