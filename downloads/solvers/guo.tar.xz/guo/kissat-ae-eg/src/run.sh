#!/bin/bash
SCRIPT_DIR=$(dirname "$0")
SCRIPT_DIR=$(cd "$SCRIPT_DIR" && pwd)
cnf=$1
proof_output_file=$2
if [[ ! -x "$SCRIPT_DIR/original-run.sh" ]]; then
  exit 1
fi
output_dir=$(dirname "$proof_output_file")
mkdir -p "$output_dir" || exit 1
"$SCRIPT_DIR/original-run.sh" "$cnf" "$output_dir"
exit_code=$?
if [[ $exit_code -ne 0 ]]; then
  exit $exit_code
fi
if [[ ! -f "$output_dir/proof.out" ]]; then
  exit 3
fi
mv "$output_dir/proof.out" "$proof_output_file" || exit 4
exit 0
