#include "restart.h"
#include "backtrack.h"
#include "bump.h"
#include "decide.h"
#include "internal.h"
#include "kimits.h"
#include "logging.h"
#include "print.h"
#include "reluctant.h"
#include "report.h"

#include <inttypes.h>
#include <math.h>

bool kissat_restarting (kissat *solver) {
  assert (solver->unassigned);
  if (!GET_OPTION (restart))
    return false;
  if (!solver->level)
    return false;
  if (CONFLICTS < solver->limits.restart.conflicts)
    return false;
  if (solver->stable)
    return kissat_reluctant_triggered (&solver->reluctant);
  const double fast = AVERAGE (fast_glue);
  const double slow = AVERAGE (slow_glue);
  const double margin = (100.0 + GET_OPTION (restartmargin)) / 100.0;
  const double limit = margin * slow;
  kissat_extremely_verbose (solver,
                            "restart glue limit %g = "
                            "%.02f * %g (slow glue) %c %g (fast glue)",
                            limit, margin, slow,
                            (limit > fast    ? '>'
                             : limit == fast ? '='
                                             : '<'),
                            fast);
  return (limit <= fast);
}

void kissat_update_focused_restart_limit (kissat *solver) {
  assert (!solver->stable);
  limits *limits = &solver->limits;
  uint64_t restarts = solver->statistics.restarts;
  uint64_t delta = GET_OPTION (restartint);
  if (restarts)
    delta += kissat_logn (restarts) - 1;
  limits->restart.conflicts = CONFLICTS + delta;
  kissat_extremely_verbose (solver,
                            "focused restart limit at %" PRIu64
                            " after %" PRIu64 " conflicts ",
                            limits->restart.conflicts, delta);
}

static unsigned reuse_stable_trail (kissat *solver) {
  const heap *const scores = kissat_get_scores(solver);
  const unsigned next_idx = kissat_next_decision_variable (solver);
  const double limit = kissat_get_heap_score (scores, next_idx);
  unsigned level = solver->level, res = 0;
  while (res < level) {
    frame *f = &FRAME (res + 1);
    const unsigned idx = IDX (f->decision);
    const double score = kissat_get_heap_score (scores, idx);
    if (score <= limit)
      break;
    res++;
  }
  return res;
}

static unsigned reuse_focused_trail (kissat *solver) {
  const links *const links = solver->links;
  const unsigned next_idx = kissat_next_decision_variable (solver);
  const unsigned limit = links[next_idx].stamp;
  LOG ("next decision variable stamp %u", limit);
  unsigned level = solver->level, res = 0;
  while (res < level) {
    frame *f = &FRAME (res + 1);
    const unsigned idx = IDX (f->decision);
    const unsigned score = links[idx].stamp;
    if (score <= limit)
      break;
    res++;
  }
  return res;
}

static unsigned reuse_trail (kissat *solver) {
  assert (solver->level);
  assert (!EMPTY_STACK (solver->trail));

  if (!GET_OPTION (restartreusetrail))
    return 0;

  unsigned res;

  if (solver->stable)
    res = reuse_stable_trail (solver);
  else
    res = reuse_focused_trail (solver);

  LOG ("matching trail level %u", res);

  if (res) {
    INC (restarts_reused_trails);
    ADD (restarts_reused_levels, res);
    LOG ("restart reuses trail at decision level %u", res);
  } else
    LOG ("restarts does not reuse the trail");

  return res;
}

void restart_mab(kissat *solver) {
    unsigned stable_restarts = 0;

    // Hybrid reward:
    // 1) decisions/conflicts favors faster progress
    // 2) lower glue gives a small quality bonus
    // 3) chosen/divisions ratio rewards broader useful branching a little
    if (solver->mab_decisions > 0) {
      const double d = (double) solver->mab_decisions;
      const double c = (double) (solver->mab_conflicts ? solver->mab_conflicts : 1);
      const double speed = d / c;
      const double diversity = (double) solver->mab_chosen_tot / d;
      double quality = 0.0;
      if (solver->mab_conflicts > 0) {
        const double fast_g = AVERAGE (fast_glue);
        const double slow_g = AVERAGE (slow_glue);
        const double avg_glue = (fast_g + slow_g) * 0.5;
        if (avg_glue > 0.0)
          quality = 1.0 / avg_glue;
      }
      double r = speed * (1.0 + 0.10 * diversity) + 2.0 * quality;
      if (r > 1e6) r = 1e6;
      solver->mab_reward[solver->heuristic] += r;
    }

    for (all_variables(idx)) {
        solver->mab_chosen[idx] = 0;
    }
    solver->mab_chosen_tot = 0;
    solver->mab_decisions = 0;
    solver->mab_conflicts = 0;
    
    for (unsigned i = 0; i < solver->mab_heuristics; i++) {
        stable_restarts += solver->mab_select[i];
    }

    // Decaying epsilon-greedy, but keep a small exploration bonus even when exploiting
    // to avoid committing too early after a lucky epoch.
    double eps = 0.25;
    if (stable_restarts > 0) {
      eps = 0.25 / sqrt ((double) stable_restarts + 1.0);
      if (eps < 0.02) eps = 0.02;
    }

    // Ensure every heuristic is tried at least once.
    for (unsigned i = 0; i < solver->mab_heuristics; i++) {
      if (!solver->mab_select[i]) {
        solver->heuristic = i;
        goto chosen;
      }
    }

    if (kissat_pick_double (&solver->random) < eps) {
      solver->heuristic =
          kissat_pick_random (&solver->random, 0, solver->mab_heuristics);
    } else {
      solver->heuristic = 0;
      double best = -1.0;
      for (unsigned i = 0; i < solver->mab_heuristics; i++) {
        const double n = (double) solver->mab_select[i];
        const double mean = solver->mab_reward[i] / n;
        const double bonus =
            0.05 * sqrt (log ((double) stable_restarts + 1.0) / n);
        const double score = mean + bonus;
        if (i == 0 || score > best) {
          best = score;
          solver->heuristic = i;
        }
      }
    }

chosen:
    solver->mab_select[solver->heuristic]++;
}

void kissat_restart (kissat *solver) {
  START (restart);
  INC (restarts);
  ADD (restarts_levels, solver->level);
  if (solver->stable)
    INC (stable_restarts);
  else
    INC (focused_restarts);

  unsigned old_heuristic = solver->heuristic;
  if (solver->stable && solver->mab) 
      restart_mab(solver);
  unsigned new_heuristic = solver->heuristic;

  unsigned level = old_heuristic==new_heuristic?reuse_trail (solver):0;

  kissat_extremely_verbose (solver,
                            "restarting after %" PRIu64 " conflicts"
                            " (limit %" PRIu64 ")",
                            CONFLICTS, solver->limits.restart.conflicts);
  LOG ("restarting to level %u", level);
  if (solver->stable && solver->mab) solver->heuristic = old_heuristic;
  kissat_backtrack_in_consistent_state (solver, level);
  if (solver->stable && solver->mab) solver->heuristic = new_heuristic;
  if (!solver->stable)
    kissat_update_focused_restart_limit (solver);
  
  if (solver->stable && solver->mab && old_heuristic!=new_heuristic) kissat_update_scores(solver);

  REPORT (1, 'R');
  STOP (restart);
}
