#!/bin/bash

docker build --platform linux/amd64 -t satcomp26 -f Dockerfile .

# docker run -it --rm \
#     --name satcomp26 \
#     --platform linux/amd64 \
#     satcomp26:latest