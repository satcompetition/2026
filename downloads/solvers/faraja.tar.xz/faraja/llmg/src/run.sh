#!/bin/bash
if [ -z "$1" ] || [ -z "$2" ]; then
    echo "Usage: $0 <benchmark.cnf> <proof_dir>"
    exit 1
fi

BENCHMARK=$1
PROOF_DIR=$2
PROOF_FILE="$PROOF_DIR/proof.out"

# Ensure the proof directory exists
mkdir -p "$PROOF_DIR"

# Execute the solver
# The solver prints the required output to stdout.
# We redirect stderr to proof.out to capture the proof-trace.
node dist/sat.mjs "$BENCHMARK" --llm 2> "$PROOF_FILE"
