#!/bin/bash
# Install dependencies cleanly
npm ci

# Build the solver using esbuild (configured in package.json)
npm run build
