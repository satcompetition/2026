#!/bin/bash
# run-parsl.sh — call binary directly (solver: llmg)
# Usage: ./run-parsl.sh <cnf> <proof_output_file>
cd "$(dirname "$0")"
CNF="$1"
PROOF="$2"
node dist/sat.mjs "$CNF" --llm 2> "$PROOF"
