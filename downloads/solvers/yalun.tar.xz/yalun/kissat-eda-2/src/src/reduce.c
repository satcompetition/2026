#include "reduce.h"
#include "allocate.h"
#include "collect.h"
#include "inline.h"
#include "print.h"
#include "rank.h"
#include "report.h"
#include "tiers.h"
#include "trail.h"

#include <inttypes.h>
#include <math.h>

// Global variable definition (declared as extern in reduce.h)
bool use_new_reduce_strategy = true;

static const double LOGREG_W[435] = {
  0.024704979732632637, -61.826793670654297, -32.700523376464844, -19.287376403808594, 10.163554191589355, -0.63713663816452026,
  4.1043424606323242, -15.261072158813477, -15.55192756652832, -36.317008972167969, -29.568498611450195, -25.588142395019531,
  -26.755401611328125, -38.715251922607422, -17.883502960205078, -11.360503196716309, 1.2919735908508301, 1.3963689804077148,
  21.777996063232422, 21.450090408325195, 33.992019653320312, 22.867454528808594, 25.797756195068359, 29.210414886474609,
  23.806896209716797, 19.532093048095703, 27.577472686767578, 12.243465423583984, 19.069841384887695, -62.493587493896484,
  -37.120864868164062, -21.380636215209961, 3.1172337532043457, 7.918086051940918, 2.1100544929504395, -16.22474479675293,
  -20.308921813964844, -32.125701904296875, -34.302341461181641, -39.061244964599609, -35.400833129882812, -42.303451538085938,
  -39.315570831298828, -32.338676452636719, -39.390750885009766, -37.255931854248047, -22.06556510925293, -16.37645149230957,
  -26.843910217285156, -22.390436172485352, -27.250028610229492, -23.960922241210938, -28.946182250976562, -30.432586669921875,
  -31.849447250366211, -22.194631576538086, -27.768331527709961, -22.396932601928711, -20.101753234863281, 10.69766902923584,
  18.83131217956543, 26.139619827270508, -8.2969932556152344, -12.673323631286621, -16.30805778503418, -25.119167327880859,
  -30.344671249389648, -29.429786682128906, -35.880992889404297, -27.668006896972656, -24.391111373901367, -21.831064224243164,
  -19.998077392578125, -17.06657600402832, -13.146383285522461, -22.391878128051758, -22.607158660888672, -18.372951507568359,
  -27.966754913330078, -21.013654708862305, -36.724437713623047, -36.692882537841797, -37.983341217041016, -27.440544128417969,
  -2.4627022743225098, 14.56397533416748, 27.412513732910156, 27.829702377319336, -0.82048815488815308, -2.9105439186096191,
  -2.7029068470001221, -4.0190591812133789, -15.588175773620605, -19.626436233520508, -21.159368515014648, -15.317716598510742,
  -11.243690490722656, -0.039744701236486435, 1.1979258060455322, 3.1860752105712891, 2.1076066493988037, -4.1100935935974121,
  -0.22904220223426819, 3.2446060180664062, -2.2974655628204346, -8.514068603515625, -12.600803375244141, -17.544898986816406,
  -13.458963394165039, -14.846455574035645, 8.7097768783569336, 26.782659530639648, 31.700384140014648, 5.24835205078125,
  3.7002279758453369, 4.2914843559265137, 4.3545722961425781, -4.8819727897644043, -13.372918128967285, -18.356754302978516,
  -13.144783020019531, -6.0966148376464844, 4.8114542961120605, 11.074459075927734, 15.950095176696777, 17.720956802368164,
  15.872621536254883, 13.951435089111328, 13.604132652282715, 8.2501850128173828, 11.075827598571777, 2.2627615928649902,
  2.2724130153656006, -0.78793156147003174, 11.664539337158203, 20.772336959838867, 27.999410629272461, 10.864910125732422,
  8.1742086410522461, 9.0803794860839844, 8.0445089340209961, -0.49305763840675354, -11.109764099121094, -16.015066146850586,
  -13.909641265869141, -10.260895729064941, 2.1795783042907715, 10.932643890380859, 19.024196624755859, 21.65397834777832,
  23.285867691040039, 21.627239227294922, 19.574941635131836, 18.355438232421875, 17.167312622070312, 13.254522323608398,
  9.2067756652832031, 10.618042945861816, 16.47300910949707, 19.152185440063477, 11.547347068786621, 10.634716987609863,
  9.9538450241088867, 7.848991870880127, -1.5858035087585449, -9.8877277374267578, -16.063621520996094, -16.394960403442383,
  -14.563843727111816, -4.4330439567565918, 1.1881973743438721, 14.281845092773438, 18.961578369140625, 19.711177825927734,
  19.382438659667969, 19.183755874633789, 14.65358829498291, 14.126431465148926, 16.165641784667969, 15.954510688781738,
  14.600221633911133, 19.338916778564453, 11.412619590759277, 9.2393894195556641, 9.2062606811523438, 6.2037630081176758,
  -2.2550768852233887, -10.081976890563965, -15.398905754089355, -18.067955017089844, -16.108432769775391, -11.331742286682129,
  -5.3836021423339844, 8.3788242340087891, 13.413290977478027, 16.417957305908203, 16.490879058837891, 17.80772590637207,
  14.855274200439453, 14.277603149414062, 12.20744800567627, 14.512050628662109, 16.469127655029297, 21.603610992431641,
  16.168869018554688, 5.2119064331054688, 5.3411402702331543, -3.2089879512786865, -10.012474060058594, -15.494907379150391,
  -18.705785751342773, -17.075557708740234, -13.76682186126709, -7.5237894058227539, 2.8236582279205322, 8.9828920364379883,
  12.081524848937988, 13.391267776489258, 14.755212783813477, 13.566553115844727, 11.509584426879883, 11.785734176635742,
  15.445030212402344, 18.877315521240234, 22.069210052490234, 21.192962646484375, -0.053823571652173996, -4.5364370346069336,
  -10.53083610534668, -15.155735015869141, -16.519996643066406, -16.927267074584961, -13.314735412597656, -9.3666229248046875,
  -1.4159994125366211, 2.6447558403015137, 8.4595527648925781, 9.7919950485229492, 13.010432243347168, 10.478321075439453,
  12.059175491333008, 10.865703582763672, 15.667787551879883, 18.955459594726562, 21.541614532470703, 27.763296127319336,
  -6.369868278503418, -9.0131597518920898, -12.503007888793945, -15.500039100646973, -13.893088340759277, -13.335483551025391,
  -11.141371726989746, -4.422368049621582, -0.49424108862876892, 2.9772598743438721, 6.2700543403625488, 13.590195655822754,
  9.7794609069824219, 10.513019561767578, 12.490972518920898, 16.614124298095703, 18.669431686401367, 22.929878234863281,
  32.760097503662109, -9.235569953918457, -7.7519350051879883, -11.940893173217773, -13.100055694580078, -13.145520210266113,
  -10.781006813049316, -7.025963306427002, -4.2170548439025879, 0.36094856262207031, 3.8571734428405762, 9.7465658187866211,
  9.6399936676025391, 11.50566577911377, 12.097511291503906, 17.321128845214844, 20.034940719604492, 22.160882949829102,
  39.450557708740234, -8.4762125015258789, -7.9532690048217773, -9.5295267105102539, -10.963852882385254, -10.046351432800293,
  -6.9756326675415039, -8.2384128570556641, -3.156909704208374, 1.6658300161361694, 8.2689237594604492, 8.2051229476928711,
  11.395296096801758, 12.628466606140137, 17.691822052001953, 21.252033233642578, 23.706209182739258, 45.227245330810547,
  -5.5676870346069336, -5.8709774017333984, -6.3811821937561035, -7.9517660140991211, -8.6565895080566406, -6.3138971328735352,
  -6.3237676620483398, -0.99716860055923462, 4.0989270210266113, 6.2457075119018555, 9.9849014282226562, 15.570636749267578,
  17.805597305297852, 21.571836471557617, 23.58506965637207, 48.051647186279297, -4.4605488777160645, -3.2344622611999512,
  -4.8443384170532227, -5.5996522903442383, -8.0795001983642578, -6.9967622756958008, -4.3440837860107422, 2.7227129936218262,
  2.8437674045562744, 8.6540985107421875, 14.16981315612793, 18.422433853149414, 23.698799133300781, 24.409746170043945,
  49.716720581054688, -1.3528245687484741, -1.4190443754196167, -3.4397513866424561, -5.3843145370483398, -6.8481121063232422,
  -5.4982280731201172, -0.9298173189163208, 2.0418453216552734, 6.7977900505065918, 13.398667335510254, 18.548282623291016,
  23.694984436035156, 25.476524353027344, 49.837886810302734, 0.052741561084985733, 0.32714986801147461, -2.4481997489929199,
  -4.048576831817627, -4.9072122573852539, -1.3692992925643921, -1.7923084497451782, 2.1059730052947998, 8.0720529556274414,
  15.857288360595703, 20.899787902832031, 23.766220092773438, 47.078567504882812, 0.69184929132461548, 2.6723988056182861,
  -0.54076629877090454, -1.5992429256439209, -1.6497956514358521, -1.9199470281600952, -0.57963144779205322, 6.813509464263916,
  13.40834903717041, 16.05211067199707, 20.016885757446289, 44.353981018066406, 2.5608000755310059, 4.7355165481567383,
  0.84305542707443237, 0.43480011820793152, -1.9914554357528687, -1.2913109064102173, 2.6854636669158936, 5.9236702919006348,
  8.9256429672241211, 11.742366790771484, 40.231124877929688, 3.2948527336120605, 4.7831177711486816, 1.0322877168655396,
  -1.8013560771942139, -4.7357802391052246, -1.3138445615768433, 0.1572711318731308, -0.38732123374938965, 4.0292201042175293,
  36.058403015136719, 0.3793962299823761, 5.3306808471679688, -0.63762390613555908, -6.8575754165649414, -8.091609001159668,
  -8.8206768035888672, -8.0441551208496094, -4.0818510055541992, 29.694549560546875, -0.10114022344350815, -2.0723109245300293,
  -7.495887279510498, -9.9367609024047852, -11.24506664276123, -17.975603103637695, -15.634100914001465, 21.236595153808594,
  -9.901057243347168, -7.606407642364502, -15.290140151977539, -20.418416976928711, -23.156007766723633, -27.171173095703125,
  10.427779197692871, -17.528526306152344, -18.121219635009766, -21.593975067138672, -28.633077621459961, -32.562015533447266,
  0.35441985726356506, -25.178255081176758, -27.970775604248047, -31.67573356628418, -37.031463623046875, -12.819073677062988,
  -36.140918731689453, -35.127159118652344, -38.255954742431641, -24.080183029174805, -41.805564880371094, -45.825088500976562,
  -34.927501678466797, -52.415012359619141, -43.422069549560547
};

static const double LOGREG_B = -0.42915952205657959;



bool kissat_logreg_predict_clause_count (kissat *solver) {
  double feats[435];
  double sum = 0.0;
  int k = 0;
  for (int i = 1; i <= 30; ++i) {
    for (int j = i + 1; j <= 30; ++j) {
      const double v = (double) solver->clause_count[i][j];
      const double lv = log1p (v);
      feats[k++] = lv;
      sum += lv;
    }
  }
  const double inv = 1.0 / (sum + 1e-8);
  double dot = LOGREG_B;
  for (int t = 0; t < 435; ++t)
    dot += LOGREG_W[t] * (feats[t] * inv);

  // prob = sigmoid(dot).  Using threshold 0.5 is equivalent to (dot >= 0).
  return dot >= 0.0;
}


bool kissat_reducing (kissat *solver) {
  if (!GET_OPTION (reduce))
    return false;
  if (!solver->statistics.clauses_redundant)
    return false;
  if (CONFLICTS < solver->limits.reduce.conflicts)
    return false;
  return true;
}

bool kissat_decaying (kissat *solver) {
  
 
  if ((CONFLICTS & ((1<<12)-1)))  
    return false;
  return true;
}

bool kissat_output_clause_count(kissat *solver) {
  if (CONFLICTS==500000)
    return true;
  return false;
}

void kissat_decay (kissat *solver) {
  for (all_clauses (c)) {
    if (!c->redundant)
      continue;
    if (c->garbage)
      continue;
    if (c->lru_time_stamp)
      --c->lru_time_stamp;
  }
}

// void kissat_decay (kissat *solver) {
//   uint64_t lru_sum[26] = {0};
//   uint64_t lru_count[26] = {0};
//   for (all_clauses (c)) {
//     if (!c->redundant) continue;
//     if (c->garbage) continue;
//     if (c->glue >= 1 && c->glue <= 25) {
//       lru_sum[c->glue] += c->lru_time_stamp;
//       lru_count[c->glue]++;
//     }
//     if (c->lru_time_stamp)
//       --c->lru_time_stamp;
//   }
//   for (int i = 1; i <= 25; ++i) {
//     if (lru_count[i])
//       solver->average_score[i] = (unsigned)round((double)lru_sum[i] / lru_count[i]);
//     else
//       solver->average_score[i] = 0;
//   }
// }

bool kissat_observing (kissat *solver) {
  if (CONFLICTS==150000)
    return true;
  return false;
}



// void kissat_observe(kissat *solver) {
//     FILE *fp = fopen("./score_matrix.txt", "w");
//     if (!fp) return;

//     fprintf(fp, "     ");
//     for (int j = 1; j <= 30; ++j) {
//         fprintf(fp, "%5d ", j);
//     }
//     fprintf(fp, "\n");

//     for (int i = 1; i <= 30; ++i) {
//         fprintf(fp, "%3d: ", i);
//         for (int j = 1; j <= 30; ++j) {
//             uint64_t avg = 0;
//             if (solver->clause_count[i][j] != 0) {
//                 avg = (uint64_t)((double)solver->total_score[i][j] / (double)solver->clause_count[i][j]);
//             }
//             fprintf(fp, "%5" PRIu64 " ", avg);
//         }
//         fprintf(fp, "\n");
//     }

//     fclose(fp);
// }

void kissat_observe_clause_count(kissat *solver) {
  if(!solver->observe_output_path)return;
  const char *output_path = solver->observe_output_path ? solver->observe_output_path : "./clause_count.txt";
  FILE *fp = fopen(output_path, "w");
  if (!fp) return;

  fprintf(fp, "     ");
  for (int j = 1; j <= 30; ++j) {
      fprintf(fp, "%5d ", j);
  }
  fprintf(fp, "\n");

  for (int i = 1; i <= 30; ++i) {
      fprintf(fp, "%3d: ", i);
      for (int j = 1; j <= 30; ++j) {
          uint64_t avg = solver->clause_count[i][j];
          fprintf(fp, "%5" PRIu64 " ", avg);
      }
      fprintf(fp, "\n");
  }

  fclose(fp);
}

typedef struct reducible reducible;

struct reducible {
  uint64_t rank;
  unsigned ref;
};

#define RANK_REDUCIBLE(RED) (RED).rank

// clang-format off
typedef STACK (reducible) reducibles;
// clang-format on

static bool collect_reducibles (kissat *solver, reducibles *reds,
                                reference start_ref) {
  assert (start_ref != INVALID_REF);
  assert (start_ref <= SIZE_STACK (solver->arena));
  ward *const arena = BEGIN_STACK (solver->arena);
  clause *start = (clause *) (arena + start_ref);
  const clause *const end = (clause *) END_STACK (solver->arena);
  assert (start < end);
  while (start != end && !start->redundant)
    start = kissat_next_clause (start);
  if (start == end) {
    solver->first_reducible = INVALID_REF;
    LOG ("no reducible clause candidate left");
    return false;
  }
  const reference redundant = (ward *) start - arena;
#ifdef LOGGING
  if (redundant < solver->first_reducible)
    LOG ("updating start of redundant clauses from %zu to %zu",
         (size_t) solver->first_reducible, (size_t) redundant);
  else
    LOG ("no update to start of redundant clauses %zu",
         (size_t) solver->first_reducible);
#endif
  solver->first_reducible = redundant;
  const unsigned tier1 = TIER1;
  const unsigned tier2 = MAX (tier1, TIER2);
  assert (tier1 <= tier2);
  for (clause *c = start; c != end; c = kissat_next_clause (c)) {
    if (!c->redundant)
      continue;
    if (c->garbage)
      continue;
    const unsigned used = c->used;
    if (used)
      c->used = used - 1;
    if (c->reason)
      continue;

if(!use_new_reduce_strategy){
     const unsigned glue = c->glue;
    if (glue <= tier1 && used)
      continue;
    if (glue <= tier2 && used >= MAX_USED - 1)
      continue;
}
else{
    if(c->lru_time_stamp){
        continue;
    }
}

   
    assert (kissat_clause_in_arena (solver, c));
    reducible red;
if(use_new_reduce_strategy){
    const uint64_t negative_size = ~c->size;
    red.rank = negative_size;
  }
else{
    const uint64_t negative_size = ~c->size;
    const uint64_t negative_glue = ~c->glue;
    red.rank = negative_size | (negative_glue << 32);
}
    red.ref = (ward *) c - arena;
    PUSH_STACK (*reds, red);
  

  }
  if (EMPTY_STACK (*reds)) {
    kissat_phase (solver, "reduce", GET (reductions),
                  "did not find any reducible redundant clause");
    return false;
  }
  return true;
}

#define USEFULNESS RANK_REDUCIBLE

static void sort_reducibles (kissat *solver, reducibles *reds) {
  RADIX_STACK (reducible, uint64_t, *reds, USEFULNESS);
}

static void mark_less_useful_clauses_as_garbage (kissat *solver,
                                                 reducibles *reds) {
  statistics *statistics = &solver->statistics;
  const double high = GET_OPTION (reducehigh) * 0.1;
  const double low = GET_OPTION (reducelow) * 0.1;
  double percent;
  if (low < high) {
    const double delta = high - low;
    percent = high - delta / log10 (statistics->reductions + 9);
  } else
    percent = low;
  const double fraction = percent / 100.0;
  const size_t size = SIZE_STACK (*reds);
  size_t target = size * fraction;
#ifndef QUIET
  const size_t clauses =
      statistics->clauses_irredundant + statistics->clauses_redundant;
  kissat_phase (solver, "reduce", GET (reductions),
                "reducing %zu (%.0f%%) out of %zu (%.0f%%) "
                "reducible clauses",
                target, kissat_percent (target, size), size,
                kissat_percent (size, clauses));
#endif
  unsigned reduced = 0, reduced1 = 0, reduced2 = 0, reduced3 = 0;
  ward *arena = BEGIN_STACK (solver->arena);
  const reducible *const begin = BEGIN_STACK (*reds);
  const reducible *const end = END_STACK (*reds);
  const unsigned tier1 = TIER1;
  const unsigned tier2 = TIER2;
  for (const reducible *p = begin; p != end && target--; p++) {
    clause *c = (clause *) (arena + p->ref);
    assert (kissat_clause_in_arena (solver, c));
    assert (!c->garbage);
    assert (!c->reason);
    assert (c->redundant);
    LOGCLS (c, "reducing");
    kissat_mark_clause_as_garbage (solver, c);
    reduced++;
    if (c->glue <= tier1)
      reduced1++;
    else if (c->glue <= tier2)
      reduced2++;
    else
      reduced3++;
  }
  ADD (clauses_reduced_tier1, reduced1);
  ADD (clauses_reduced_tier2, reduced2);
  ADD (clauses_reduced_tier3, reduced3);
  ADD (clauses_reduced, reduced);
}

int kissat_reduce (kissat *solver) {
  START (reduce);
  INC (reductions);
  kissat_phase (solver, "reduce", GET (reductions),
                "reduce limit %" PRIu64 " hit after %" PRIu64 " conflicts",
                solver->limits.reduce.conflicts, CONFLICTS);
  kissat_compute_and_set_tier_limits (solver);
  bool compact = kissat_compacting (solver);
  reference start = compact ? 0 : solver->first_reducible;
  if (start != INVALID_REF) {
#ifndef QUIET
    size_t arena_size = SIZE_STACK (solver->arena);
    size_t words_to_sweep = arena_size - start;
    size_t bytes_to_sweep = sizeof (word) * words_to_sweep;
    kissat_phase (solver, "reduce", GET (reductions),
                  "reducing clauses after offset %" REFERENCE_FORMAT
                  " in arena",
                  start);
    kissat_phase (solver, "reduce", GET (reductions),
                  "reducing %zu words %s %.0f%%", words_to_sweep,
                  FORMAT_BYTES (bytes_to_sweep),
                  kissat_percent (words_to_sweep, arena_size));
#endif
    if (kissat_flush_and_mark_reason_clauses (solver, start)) {
      reducibles reds;
      INIT_STACK (reds);
      if (collect_reducibles (solver, &reds, start)) {
        sort_reducibles (solver, &reds);
        mark_less_useful_clauses_as_garbage (solver, &reds);
        RELEASE_STACK (reds);
        kissat_sparse_collect (solver, compact, start);
      } else if (compact)
        kissat_sparse_collect (solver, compact, start);
      else
        kissat_unmark_reason_clauses (solver, start);
    } else
      assert (solver->inconsistent);
  } else
    kissat_phase (solver, "reduce", GET (reductions), "nothing to reduce");
  kissat_classify (solver);
  UPDATE_CONFLICT_LIMIT (reduce, reductions, SQRT, false);
  solver->last.conflicts.reduce = CONFLICTS;
  REPORT (0, '-');
  STOP (reduce);
  return solver->inconsistent ? 20 : 0;
}
