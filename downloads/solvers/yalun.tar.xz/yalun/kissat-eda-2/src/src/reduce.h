#ifndef _reduce_h_INCLUDED
#define _reduce_h_INCLUDED

#include <stdbool.h>

struct kissat;

bool kissat_reducing (struct kissat *);
int kissat_reduce (struct kissat *);
bool kissat_decaying (struct kissat *);
void kissat_decay (struct kissat *);
bool kissat_output_clause_count(struct kissat *);
bool kissat_logreg_predict_clause_count (struct kissat *);

bool kissat_observing (struct kissat *);
// void kissat_observe (struct kissat *);
void kissat_observe_clause_count (struct kissat *);

extern bool use_new_reduce_strategy;

// uint64_t average_score[26];

#endif
