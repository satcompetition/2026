#!/bin/bash

if [[ $# -ne 2 ]]; then
    echo "Usage: $0 <cnf> <proof_output_file>"
    exit 1
fi

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
ORIGINAL_RUN="$SCRIPT_DIR/original-run.sh"
CNF_FILE="$1"
PROOF_OUTPUT_FILE="$2"
PROOF_DIR=$(dirname "$PROOF_OUTPUT_FILE")

if [[ ! -x "$ORIGINAL_RUN" ]]; then
    echo "Error: original-run.sh not found or not executable: $ORIGINAL_RUN"
    exit 1
fi

mkdir -p "$PROOF_DIR" || exit 1

"$ORIGINAL_RUN" "$CNF_FILE" "$PROOF_DIR"
exit_code=$?
if [[ $exit_code -ne 0 ]]; then
    exit $exit_code
fi

if [[ ! -f "$PROOF_DIR/proof.out" ]]; then
    echo "Error: proof file not found: $PROOF_DIR/proof.out"
    exit 3
fi

mv "$PROOF_DIR/proof.out" "$PROOF_OUTPUT_FILE" || exit 4
exit 0
