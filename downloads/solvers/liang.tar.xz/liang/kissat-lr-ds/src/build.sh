#!/bin/bash
./configure
make
