#!/bin/bash
# run-parsl.sh — call binary directly (solver: kissat-lr-ds)
# Usage: ./run-parsl.sh <cnf> <proof_output_file>
cd "$(dirname "$0")"
CNF="$1"
PROOF="$2"
./build/kissat "$CNF" "$PROOF"
